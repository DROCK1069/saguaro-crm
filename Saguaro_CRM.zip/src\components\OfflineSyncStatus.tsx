/**
 * Offline Sync Status Indicator Component
 * Shows sync status and queued operations count
 */

'use client';

import React, { useEffect, useState } from 'react';
import { offlineSync, getSyncStatus } from '@/lib/offlineSync';

interface SyncStatus {
  isOnline: boolean;
  queued: number;
  syncing: boolean;
  lastSyncTime: Date | null;
}

export default function OfflineSyncStatus() {
  const [status, setStatus] = useState<SyncStatus>({
    isOnline: true,
    queued: 0,
    syncing: false,
    lastSyncTime: null,
  });

  useEffect(() => {
    // Initialize offline sync on mount
    offlineSync.init().catch(console.error);

    // Poll status every 2 seconds
    const interval = setInterval(() => {
      try {
        const currentStatus = getSyncStatus();
        setStatus(currentStatus);
      } catch (error) {
        console.error('Failed to get sync status:', error);
      }
    }, 2000);

    // Listen for online/offline events
    const handleOnline = () => setStatus(prev => ({ ...prev, isOnline: true }));
    const handleOffline = () => setStatus(prev => ({ ...prev, isOnline: false }));

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      clearInterval(interval);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const iconColor = status.isOnline ? '#10b981' : '#ef4444';
  const iconLabel = status.isOnline
    ? `Online${status.queued > 0 ? ` - ${status.queued} pending` : ''}`
    : 'Offline - Changes saved locally';

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        padding: '8px 12px',
        borderRadius: '4px',
        backgroundColor: status.isOnline ? '#f0fdf4' : '#fef2f2',
        border: `1px solid ${iconColor}`,
        fontSize: '14px',
        color: iconColor,
      }}
      title={iconLabel}
    >
      <span
        style={{
          width: '8px',
          height: '8px',
          borderRadius: '50%',
          backgroundColor: iconColor,
          animation: status.isOnline ? 'none' : 'pulse 2s infinite',
        }}
      />
      {status.isOnline ? 'Online' : 'Offline'}
      {status.queued > 0 && (
        <>
          <span style={{ margin: '0 4px' }}>•</span>
          <span>{status.queued} pending</span>
        </>
      )}
      {status.syncing && <span style={{ marginLeft: '4px' }}>... syncing</span>}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </div>
  );
}
