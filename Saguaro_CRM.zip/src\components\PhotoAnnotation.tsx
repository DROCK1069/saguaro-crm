'use client';

import React, { useRef, useEffect, useState } from 'react';
import { supabaseAdmin } from '@/supabase/admin';

export interface AnnotationPoint {
  x: number;
  y: number;
  type: 'draw' | 'text' | 'measure';
  data?: string;
  timestamp: number;
}

interface PhotoAnnotationProps {
  photoId: string;
  photoUrl: string;
  projectId: string;
  onSave?: (annotations: AnnotationPoint[]) => void;
  isReadOnly?: boolean;
}

const PhotoAnnotation: React.FC<PhotoAnnotationProps> = ({
  photoId,
  photoUrl,
  projectId,
  onSave,
  isReadOnly = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<'draw' | 'text' | 'measure'>('draw');
  const [color, setColor] = useState('#FF0000');
  const [brushSize, setBrushSize] = useState(3);
  const [annotations, setAnnotations] = useState<AnnotationPoint[]>([]);
  const [ctx, setCtx] = useState<CanvasRenderingContext2D | null>(null);
  const [showTexture, setShowTexture] = useState(true);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [panX, setPanX] = useState(0);
  const [panY, setPanY] = useState(0);
  const [measureStart, setMeasureStart] = useState<{ x: number; y: number } | null>(null);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext('2d');
    if (!context) return;

    // Load image
    const img = new Image();
    img.src = photoUrl;
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;

      // Draw image on canvas
      context.drawImage(img, 0, 0);
      setCtx(context);
    };

    // Load existing annotations
    loadAnnotations();
  }, [photoUrl]);

  const loadAnnotations = async () => {
    try {
      const { data, error } = await supabaseAdmin.from('project_photos')
        .select('annotations')
        .eq('id', photoId)
        .single();

      if (data?.annotations) {
        setAnnotations(data.annotations);
        redrawAnnotations(data.annotations);
      }
    } catch (err) {
      console.error('Error loading annotations:', err);
    }
  };

  const redrawAnnotations = (annos: AnnotationPoint[]) => {
    if (!ctx || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const img = new Image();
    img.src = photoUrl;
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);

      // Redraw all annotations
      annos.forEach(anno => {
        if (anno.type === 'draw') {
          const points = anno.data ? JSON.parse(anno.data) : [];
          if (points.length > 0) {
            ctx.strokeStyle = anno.data?.startsWith('#') ? anno.data.split('|')[0] : '#FF0000';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(points[0].x, points[0].y);
            points.forEach((p: { x: number; y: number }) => ctx.lineTo(p.x, p.y));
            ctx.stroke();
          }
        } else if (anno.type === 'text') {
          ctx.fillStyle = color;
          ctx.font = 'bold 16px Arial';
          ctx.fillText(anno.data || '', anno.x, anno.y);
        } else if (anno.type === 'measure') {
          const [x1, y1, x2, y2] = anno.data?.split(',').map(Number) || [0, 0, 0, 0];
          const distance = Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);

          ctx.strokeStyle = '#00FF00';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();

          ctx.fillStyle = '#00FF00';
          ctx.font = 'bold 12px Arial';
          ctx.fillText(`${distance.toFixed(0)}px`, (x1 + x2) / 2, (y1 + y2) / 2 - 5);
        }
      });
    };
  };

  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isReadOnly) return;

    const canvas = canvasRef.current;
    if (!canvas || !ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoomLevel - panX;
    const y = (e.clientY - rect.top) / zoomLevel - panY;

    if (tool === 'draw') {
      setIsDrawing(true);
      ctx.strokeStyle = color;
      ctx.lineWidth = brushSize;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(x, y);
    } else if (tool === 'measure') {
      if (!measureStart) {
        setMeasureStart({ x, y });
      } else {
        // Complete measurement
        const anno: AnnotationPoint = {
          x: measureStart.x,
          y: measureStart.y,
          type: 'measure',
          data: `${measureStart.x},${measureStart.y},${x},${y}`,
          timestamp: Date.now(),
        };
        setAnnotations([...annotations, anno]);
        redrawAnnotations([...annotations, anno]);
        setMeasureStart(null);
      }
    } else if (tool === 'text') {
      const text = prompt('Enter text annotation:', '');
      if (text) {
        const anno: AnnotationPoint = {
          x,
          y,
          type: 'text',
          data: text,
          timestamp: Date.now(),
        };
        setAnnotations([...annotations, anno]);
        redrawAnnotations([...annotations, anno]);
      }
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !ctx) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoomLevel - panX;
    const y = (e.clientY - rect.top) / zoomLevel - panY;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const handleCanvasMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !ctx) return;

    ctx.closePath();
    setIsDrawing(false);

    // Save drawing as annotation
    const canvas = canvasRef.current;
    if (canvas) {
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const anno: AnnotationPoint = {
        x: 0,
        y: 0,
        type: 'draw',
        data: JSON.stringify(imageData) + `|${color}`,
        timestamp: Date.now(),
      };
      setAnnotations([...annotations, anno]);
    }
  };

  const handleSave = async () => {
    try {
      const { error } = await supabaseAdmin.from('project_photos').update({
        annotations: annotations,
        updated_at: new Date().toISOString(),
      }).eq('id', photoId);

      if (error) throw error;

      if (onSave) {
        onSave(annotations);
      }

      alert('Annotations saved successfully!');
    } catch (err) {
      console.error('Error saving annotations:', err);
      alert('Failed to save annotations');
    }
  };

  const handleClear = () => {
    if (confirm('Clear all annotations?')) {
      setAnnotations([]);
      const canvas = canvasRef.current;
      if (canvas && ctx) {
        const img = new Image();
        img.src = photoUrl;
        img.onload = () => {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0);
        };
      }
    }
  };

  const handleUndo = () => {
    const newAnnotations = annotations.slice(0, -1);
    setAnnotations(newAnnotations);
    redrawAnnotations(newAnnotations);
  };

  return (
    <div className="w-full bg-gray-900 rounded-lg p-4">
      <div className="mb-4 flex flex-wrap gap-2 items-center">
        {!isReadOnly && (
          <>
            {/* Tool Selection */}
            <div className="flex gap-2">
              <button
                onClick={() => setTool('draw')}
                className={`px-3 py-1 rounded text-sm ${
                  tool === 'draw' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300'
                }`}
              >
                ✏️ Draw
              </button>
              <button
                onClick={() => setTool('text')}
                className={`px-3 py-1 rounded text-sm ${
                  tool === 'text' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300'
                }`}
              >
                📝 Text
              </button>
              <button
                onClick={() => setTool('measure')}
                className={`px-3 py-1 rounded text-sm ${
                  tool === 'measure' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300'
                }`}
              >
                📏 Measure
              </button>
            </div>

            {/* Color Picker */}
            {tool === 'draw' && (
              <div className="flex items-center gap-2">
                <label className="text-gray-300 text-sm">Color:</label>
                <input
                  type="color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-8 h-8 cursor-pointer"
                />
              </div>
            )}

            {/* Brush Size */}
            {tool === 'draw' && (
              <div className="flex items-center gap-2">
                <label className="text-gray-300 text-sm">Size:</label>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={brushSize}
                  onChange={(e) => setBrushSize(Number(e.target.value))}
                  className="w-24"
                />
              </div>
            )}

            {/* Zoom Controls */}
            <div className="flex gap-1">
              <button
                onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.1))}
                className="px-2 py-1 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded text-sm"
              >
                🔍−
              </button>
              <span className="text-gray-300 text-sm px-2">{Math.round(zoomLevel * 100)}%</span>
              <button
                onClick={() => setZoomLevel(Math.min(3, zoomLevel + 0.1))}
                className="px-2 py-1 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded text-sm"
              >
                🔍+
              </button>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 ml-auto">
              <button
                onClick={handleUndo}
                disabled={annotations.length === 0}
                className="px-3 py-1 bg-yellow-600 hover:bg-yellow-700 text-white rounded text-sm disabled:opacity-50"
              >
                ↶ Undo
              </button>
              <button
                onClick={handleClear}
                disabled={annotations.length === 0}
                className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-sm disabled:opacity-50"
              >
                🗑️ Clear
              </button>
              <button
                onClick={handleSave}
                className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-sm"
              >
                💾 Save
              </button>
            </div>
          </>
        )}
      </div>

      {/* Canvas Container */}
      <div className="overflow-auto bg-black rounded-lg" style={{ maxHeight: '600px' }}>
        <canvas
          ref={canvasRef}
          onMouseDown={handleCanvasMouseDown}
          onMouseMove={handleCanvasMouseMove}
          onMouseUp={handleCanvasMouseUp}
          onMouseLeave={handleCanvasMouseUp}
          className={`block mx-auto cursor-${tool === 'draw' ? 'crosshair' : 'pointer'}`}
          style={{
            transform: `scale(${zoomLevel}) translate(${panX}px, ${panY}px)`,
            transformOrigin: 'top left',
            opacity: showTexture ? 1 : 0.8,
          }}
        />
      </div>

      {/* Annotation Info */}
      <div className="mt-4 text-gray-400 text-sm">
        <p>Annotations: {annotations.length}</p>
        {measureStart && <p className="text-yellow-400">📏 Click again to complete measurement</p>}
      </div>
    </div>
  );
};

export default PhotoAnnotation;
