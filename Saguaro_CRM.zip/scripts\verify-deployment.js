/**
 * Pre-Deployment Verification Script
 * Runs all checks to ensure the app is ready for production
 *
 * Usage: node scripts/verify-deployment.js
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[36m',
};

class DeploymentVerifier {
  constructor() {
    this.checks = [];
    this.passed = 0;
    this.failed = 0;
  }

  log(message, type = 'info') {
    const icons = {
      success: '✓',
      error: '✗',
      warning: '⚠',
      info: 'ℹ',
    };
    const color = {
      success: colors.green,
      error: colors.red,
      warning: colors.yellow,
      info: colors.blue,
    };

    console.log(`${color[type]}${icons[type]} ${message}${colors.reset}`);
  }

  check(name, fn) {
    try {
      console.log(`\nChecking: ${name}`);
      fn();
      this.log(`${name} ✓`, 'success');
      this.passed++;
    } catch (err) {
      this.log(`${name} ✗ ${err.message}`, 'error');
      this.failed++;
    }
  }

  async checkAsync(name, fn) {
    try {
      console.log(`\nChecking: ${name}`);
      await fn();
      this.log(`${name} ✓`, 'success');
      this.passed++;
    } catch (err) {
      this.log(`${name} ✗ ${err.message}`, 'error');
      this.failed++;
    }
  }

  run() {
    console.log(`\n${colors.blue}╔════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.blue}║  SAGUARO CRM - DEPLOYMENT VERIFICATION  ║${colors.reset}`);
    console.log(`${colors.blue}╚════════════════════════════════════════╝${colors.reset}\n`);

    // 1. Node.js Version
    this.check('Node.js version >= 18', () => {
      const version = parseInt(process.version.split('.')[0].substring(1));
      if (version < 18) throw new Error(`Current: ${process.version}`);
    });

    // 2. Required Files
    this.check('Required files exist', () => {
      const required = [
        'package.json',
        '.env.local',
        'next.config.js',
        'src/components/OfflineSyncStatus.tsx',
        'src/components/ReportBuilder.tsx',
        'src/components/ProjectPhotoManager.tsx',
        'src/components/AlertConfigManager.tsx',
        'src/components/QuickBooksIntegration.tsx',
        'lib/offlineSync.ts',
        'lib/quickbooksClient.ts',
        'lib/reportBuilder.ts',
        'lib/alertService.ts',
        'lib/predictiveAnalytics.ts',
        'src/app/api/sync/route.ts',
        'src/app/api/reports/templates/route.ts',
        'src/app/api/alerts/config/route.ts',
        'src/app/api/alerts/log/route.ts',
        'supabase/migrations/003_add_feature_tables.sql',
      ];

      for (const file of required) {
        const filePath = path.join(process.cwd(), file);
        if (!fs.existsSync(filePath)) {
          throw new Error(`Missing file: ${file}`);
        }
      }
    });

    // 3. Environment Variables
    this.check('Environment variables configured', () => {
      const required = [
        'NEXT_PUBLIC_SUPABASE_URL',
        'NEXT_PUBLIC_SUPABASE_ANON_KEY',
        'SUPABASE_SERVICE_KEY',
        'QUICKBOOKS_CLIENT_ID',
        'QUICKBOOKS_CLIENT_SECRET',
        'QUICKBOOKS_REDIRECT_URI',
      ];

      const missing = required.filter(key => !process.env[key]);
      if (missing.length > 0) {
        throw new Error(`Missing env vars: ${missing.join(', ')}`);
      }
    });

    // 4. Package Dependencies
    this.check('npm dependencies installed', () => {
      const nodeModulesPath = path.join(process.cwd(), 'node_modules');
      if (!fs.existsSync(nodeModulesPath)) {
        throw new Error('node_modules not found. Run: npm install');
      }
    });

    // 5. Git Status (optional)
    this.check('Git repository clean (optional warning)', () => {
      try {
        const status = execSync('git status --porcelain', { encoding: 'utf8' });
        if (status.trim()) {
          this.log('Git has uncommitted changes (not required)', 'warning');
        }
      } catch {
        // Git not installed, skip
      }
    });

    // 6. TypeScript Types
    this.check('TypeScript type checking', () => {
      try {
        execSync('npx tsc --noEmit', { stdio: 'pipe' });
      } catch (err) {
        throw new Error('TypeScript errors found. Run: npm run type-check');
      }
    });

    // 7. Build Test
    this.check('Next.js production build', () => {
      try {
        console.log('  Building... (this may take a minute)');
        execSync('npm run build', { stdio: 'pipe' });
      } catch (err) {
        throw new Error('Build failed. Check build output above');
      }
    });

    // 8. .next folder
    this.check('.next build output exists', () => {
      const nextPath = path.join(process.cwd(), '.next');
      if (!fs.existsSync(nextPath)) {
        throw new Error('.next folder not found after build');
      }
    });

    // 9. Environment file check
    this.check('.env.local not in git', () => {
      try {
        const tracked = execSync('git ls-files --error-unmatch .env.local', {
          stdio: 'pipe',
        });
        if (tracked) {
          throw new Error('.env.local should NOT be committed to git!');
        }
      } catch {
        // Good - file not tracked
      }
    });

    // 10. File Size Check
    this.check('Build output size reasonable', () => {
      const nextPath = path.join(process.cwd(), '.next');
      const getSize = (dir) => {
        return fs.readdirSync(dir).reduce((size, file) => {
          const path = require('path').join(dir, file);
          const stat = fs.statSync(path);
          return size + (stat.isDirectory() ? getSize(path) : stat.size);
        }, 0);
      };

      const sizeBytes = getSize(nextPath);
      const sizeMB = sizeBytes / (1024 * 1024);

      if (sizeMB > 500) {
        this.log(
          `Large build output: ${sizeMB.toFixed(1)}MB (consider optimization)`,
          'warning'
        );
      }
    });

    // 11. Supabase Connection Test
    this.check('Supabase connection (optional)', () => {
      try {
        const canConnect = require('@supabase/supabase-js');
      } catch {
        this.log('Supabase client not installed (expected)', 'warning');
      }
    });

    // Summary
    console.log(`\n${colors.blue}╔════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.blue}║              RESULTS                    ║${colors.reset}`);
    console.log(`${colors.blue}╚════════════════════════════════════════╝${colors.reset}`);
    console.log(`${colors.green}✓ Passed: ${this.passed}${colors.reset}`);
    console.log(`${colors.red}✗ Failed: ${this.failed}${colors.reset}`);

    if (this.failed === 0) {
      console.log(`\n${colors.green}🎉 All checks passed! Ready for deployment.${colors.reset}\n`);
      console.log('Next steps:');
      console.log('1. Commit code to git: git add . && git commit -m "Deploy"');
      console.log('2. Push to hosting provider');
      console.log('3. Run post-deployment verification');
      console.log('4. Check DEPLOYMENT_GUIDE.md for detailed instructions\n');
      process.exit(0);
    } else {
      console.log(
        `\n${colors.red}❌ ${this.failed} check(s) failed. Fix issues above before deploying.${colors.reset}\n`
      );
      process.exit(1);
    }
  }
}

// Run verification
const verifier = new DeploymentVerifier();
verifier.run();
