/**
 * Slack Bot Integration Service
 * Handles incoming Slack events, commands, and interactive actions
 * Responds to RFI overdue alerts, task assignments, project updates
 */

export interface SlackMessage {
  type: string;
  user: string;
  text: string;
  ts: string;
  channel: string;
}

export interface SlackAction {
  type: string;
  actions: Array<{
    type: string;
    action_id: string;
    value?: string;
    selected_option?: { value: string };
  }>;
  team: { id: string };
  user: { id: string };
  trigger_id: string;
  response_url: string;
}

export interface SlackCommand {
  token: string;
  team_id: string;
  team_domain: string;
  channel_id: string;
  channel_name: string;
  user_id: string;
  user_name: string;
  command: string;
  text: string;
  api_app_id: string;
  response_url: string;
  trigger_id: string;
}

class SlackBotService {
  private signingSecret: string;

  constructor(signingSecret: string) {
    this.signingSecret = signingSecret;
  }

  /**
   * Verify Slack request signature for security
   */
  verifyRequest(timestamp: string, signature: string, body: string): boolean {
    // Format: v0=timestamp:body
    // Slack uses HMAC-SHA256
    const baseString = `v0:${timestamp}:${body}`;
    
    // In production, use crypto.timingSafeEqual
    // For now, just validate format
    return signature.startsWith('v0=');
  }

  /**
   * Parse Slack slash command and execute action
   */
  async handleSlashCommand(command: SlackCommand, db: any): Promise<string> {
    const { command: cmd, text, user_id, channel_id } = command;

    if (cmd === '/rfi') {
      return this.handleRFICommand(text, user_id, channel_id, db);
    } else if (cmd === '/project') {
      return this.handleProjectCommand(text, user_id, channel_id, db);
    } else if (cmd === '/sync') {
      return this.handleSyncCommand(text, user_id, db);
    }

    return 'Unknown command. Try /rfi, /project, or /sync';
  }

  private async handleRFICommand(text: string, userId: string, channelId: string, db: any): Promise<string> {
    // Parse: /rfi <rfi_id> <action>
    // Actions: acknowledge, resolve, update
    const parts = text.split(' ');
    const rfiId = parts[0];
    const action = parts[1] || 'status';

    if (action === 'acknowledge') {
      const { error } = await db.from('rfis')
        .update({
          status: 'acknowledged',
          acknowledged_by: userId,
          acknowledged_at: new Date().toISOString(),
        })
        .eq('id', rfiId);

      if (error) {
        return `Error acknowledging RFI: ${error.message}`;
      }
      return `✅ RFI ${rfiId} acknowledged!`;
    } else if (action === 'resolve') {
      const { error } = await db.from('rfis')
        .update({
          status: 'resolved',
          resolved_by: userId,
          resolved_at: new Date().toISOString(),
        })
        .eq('id', rfiId);

      if (error) {
        return `Error resolving RFI: ${error.message}`;
      }
      return `✅ RFI ${rfiId} resolved!`;
    } else {
      // Get RFI status
      const { data, error } = await db.from('rfis')
        .select('*')
        .eq('id', rfiId)
        .single();

      if (error || !data) {
        return `RFI ${rfiId} not found`;
      }

      return `📋 RFI ${data.rfi_number}\nStatus: ${data.status}\nDue: ${data.due_date}\nDays Overdue: ${data.days_overdue || 0}`;
    }
  }

  private async handleProjectCommand(text: string, userId: string, channelId: string, db: any): Promise<string> {
    // Parse: /project <project_id> <action>
    // Actions: status, update, summary
    const parts = text.split(' ');
    const projectId = parts[0];
    const action = parts[1] || 'status';

    const { data, error } = await db.from('projects')
      .select('*')
      .eq('id', projectId)
      .single();

    if (error || !data) {
      return `Project ${projectId} not found`;
    }

    if (action === 'summary') {
      // Get summary with stats
      const { data: rfis } = await db.from('rfis')
        .select('status')
        .eq('project_id', projectId);
      
      const openRfis = (rfis || []).filter((r: any) => r.status === 'open').length;

      return `📊 ${data.name}\nStatus: ${data.status}\nProgress: ${data.progress_percent || 0}%\nOpen RFIs: ${openRfis}\nBudget: $${data.value || 0}`;
    }

    return `📍 Project: ${data.name}\nStatus: ${data.status}\nProgress: ${data.progress_percent || 0}%`;
  }

  private async handleSyncCommand(text: string, userId: string, db: any): Promise<string> {
    // Trigger QuickBooks sync
    const response = await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/integrations/quickbooks/sync`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId: text }),
    });

    if (!response.ok) {
      return '❌ Sync failed. Check logs for details.';
    }

    const result = await response.json();
    return `✅ Sync complete!\n${result.message}`;
  }

  /**
   * Handle interactive button/action from Slack
   */
  async handleInteractiveAction(action: SlackAction, db: any): Promise<any> {
    const { type, actions, user, trigger_id, response_url } = action;

    if (type === 'block_actions') {
      const primaryAction = actions[0];

      if (primaryAction.action_id === 'acknowledge_rfi') {
        const rfiId = primaryAction.value;
        await db.from('rfis').update({
          status: 'acknowledged',
          acknowledged_by: user.id,
          acknowledged_at: new Date().toISOString(),
        }).eq('id', rfiId);

        return {
          response_type: 'in_channel',
          text: `✅ ${user.id} acknowledged RFI ${rfiId}`,
        };
      }

      if (primaryAction.action_id === 'resolve_rfi') {
        const rfiId = primaryAction.value;
        await db.from('rfis').update({
          status: 'resolved',
          resolved_by: user.id,
          resolved_at: new Date().toISOString(),
        }).eq('id', rfiId);

        return {
          response_type: 'in_channel',
          text: `✅ ${user.id} resolved RFI ${rfiId}`,
        };
      }

      if (primaryAction.action_id === 'view_project') {
        const projectId = primaryAction.value;
        return {
          response_type: 'ephemeral',
          text: `<${process.env.NEXT_PUBLIC_APP_URL}/project/${projectId}|View Project>`,
        };
      }
    }

    return null;
  }

  /**
   * Send rich Slack message (for alerts, notifications)
   */
  async sendSlackMessage(webhookUrl: string, blocks: any[]): Promise<boolean> {
    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ blocks }),
      });

      return response.ok;
    } catch (err) {
      console.error('Failed to send Slack message:', err);
      return false;
    }
  }

  /**
   * Create rich blocks for RFI alert
   */
  createRFIAlertBlocks(rfi: any, project: any): any[] {
    const daysOverdue = rfi.days_overdue || 0;
    const color = daysOverdue > 14 ? 'danger' : daysOverdue > 7 ? 'warning' : 'good';

    return [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*🚨 RFI ALERT*\n*${rfi.rfi_number}* | ${project.name}`,
        },
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*Status*\n${rfi.status}`,
          },
          {
            type: 'mrkdwn',
            text: `*Days Overdue*\n${daysOverdue}`,
          },
          {
            type: 'mrkdwn',
            text: `*Due Date*\n${rfi.due_date}`,
          },
          {
            type: 'mrkdwn',
            text: `*Assigned To*\n${rfi.assigned_to || 'Unassigned'}`,
          },
        ],
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Acknowledge', emoji: true },
            value: rfi.id,
            action_id: 'acknowledge_rfi',
            style: 'primary',
          },
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Resolve', emoji: true },
            value: rfi.id,
            action_id: 'resolve_rfi',
            style: 'danger',
          },
          {
            type: 'button',
            text: { type: 'plain_text', text: 'View', emoji: true },
            value: rfi.id,
            action_id: 'view_rfi',
          },
        ],
      },
    ];
  }

  /**
   * Create rich blocks for task assignment
   */
  createTaskAssignmentBlocks(task: any, project: any, assignee: string): any[] {
    return [
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: `*📌 TASK ASSIGNED*\n*${task.title}* | ${project.name}`,
        },
      },
      {
        type: 'section',
        text: {
          type: 'mrkdwn',
          text: task.description || 'No description provided',
        },
      },
      {
        type: 'section',
        fields: [
          {
            type: 'mrkdwn',
            text: `*Due Date*\n${task.planned_finish}`,
          },
          {
            type: 'mrkdwn',
            text: `*Assigned To*\n<@${assignee}>`,
          },
          {
            type: 'mrkdwn',
            text: `*Priority*\n${task.priority || 'Normal'}`,
          },
          {
            type: 'mrkdwn',
            text: `*Status*\n${task.status}`,
          },
        ],
      },
      {
        type: 'actions',
        elements: [
          {
            type: 'button',
            text: { type: 'plain_text', text: 'Start Task', emoji: true },
            value: task.id,
            action_id: 'start_task',
            style: 'primary',
          },
          {
            type: 'button',
            text: { type: 'plain_text', text: 'View', emoji: true },
            value: task.id,
            action_id: 'view_task',
          },
        ],
      },
    ];
  }
}

export const slackBot = new SlackBotService(
  process.env.SLACK_SIGNING_SECRET || ''
);
