-- Database Schema Migration
-- Run in Supabase SQL Editor to set up tables for new features

-- =====================================================
-- Phase 1: Offline Sync Tracking
-- =====================================================

CREATE TABLE IF NOT EXISTS sync_log (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  entity TEXT NOT NULL,
  action TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  local_timestamp BIGINT NOT NULL,
  server_timestamp BIGINT NOT NULL,
  status TEXT DEFAULT 'synced',
  created_at TIMESTAMP DEFAULT now()
);

CREATE INDEX sync_log_user_id ON sync_log(user_id);
CREATE INDEX sync_log_entity_id ON sync_log(entity_id);

-- =====================================================
-- Phase 1: Report Templates
-- =====================================================

CREATE TABLE IF NOT EXISTS report_templates (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  owner_id uuid NOT NULL REFERENCES auth.users(id),
  name TEXT NOT NULL,
  description TEXT,
  source_entity TEXT NOT NULL, -- 'invoices', 'rfis', 'tasks', 'projects'
  fields JSONB NOT NULL, -- [{ key, label, type, width }]
  filters JSONB NOT NULL, -- [{ field, operator, value }]
  sort_by TEXT DEFAULT 'created_at:desc',
  group_by TEXT,
  is_public BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

CREATE INDEX report_templates_owner_id ON report_templates(owner_id);

-- =====================================================
-- Phase 2: Alert Configurations
-- =====================================================

CREATE TABLE IF NOT EXISTS alert_configs (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  project_id uuid NOT NULL REFERENCES projects(id),
  type TEXT NOT NULL, -- 'slack' or 'teams'
  webhook_url TEXT NOT NULL,
  channel TEXT, -- For Slack
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now(),
  UNIQUE(project_id, type)
);

CREATE INDEX alert_configs_user_id ON alert_configs(user_id);
CREATE INDEX alert_configs_project_id ON alert_configs(project_id);

-- =====================================================
-- Phase 2: Alert Logs
-- =====================================================

CREATE TABLE IF NOT EXISTS alert_logs (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  project_id uuid NOT NULL REFERENCES projects(id),
  entity TEXT NOT NULL, -- 'rfi', 'invoice', 'task', 'project'
  entity_id TEXT NOT NULL,
  severity TEXT NOT NULL, -- 'info', 'warning', 'critical'
  title TEXT NOT NULL,
  description TEXT,
  action_url TEXT,
  sent_to JSONB, -- { slack: true, teams: true }
  created_at TIMESTAMP DEFAULT now()
);

CREATE INDEX alert_logs_user_id ON alert_logs(user_id);
CREATE INDEX alert_logs_project_id ON alert_logs(project_id);
CREATE INDEX alert_logs_severity ON alert_logs(severity);

-- =====================================================
-- Phase 2: Photo Management
-- =====================================================

CREATE TABLE IF NOT EXISTS project_photos (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id uuid NOT NULL REFERENCES projects(id),
  uploaded_by uuid NOT NULL REFERENCES auth.users(id),
  file_path TEXT NOT NULL, -- Storage bucket path
  caption TEXT,
  latitude FLOAT,
  longitude FLOAT,
  taken_at TIMESTAMP,
  linked_to_entity TEXT, -- 'rfi', 'issue', 'task', etc.
  linked_to_id TEXT,
  is_before_after BOOLEAN DEFAULT FALSE,
  before_after_pair_id uuid, -- Link to other photo in pair
  created_at TIMESTAMP DEFAULT now()
);

CREATE INDEX project_photos_project_id ON project_photos(project_id);
CREATE INDEX project_photos_linked ON project_photos(linked_to_entity, linked_to_id);

-- =====================================================
-- Phase 3: Time Entries for Geofencing
-- =====================================================

CREATE TABLE IF NOT EXISTS time_entries (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  project_id uuid NOT NULL REFERENCES projects(id),
  task_id uuid REFERENCES schedule_tasks(id),
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP,
  duration_minutes INT,
  start_location POINT, -- (latitude, longitude)
  end_location POINT,
  is_billable BOOLEAN DEFAULT TRUE,
  notes TEXT,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

CREATE INDEX time_entries_user_id ON time_entries(user_id);
CREATE INDEX time_entries_project_id ON time_entries(project_id);
CREATE INDEX time_entries_task_id ON time_entries(task_id);

-- =====================================================
-- Financial Cost Tracking (for predictions)
-- =====================================================

CREATE TABLE IF NOT EXISTS cost_entries (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id uuid NOT NULL REFERENCES projects(id),
  cost_code TEXT, -- From chart of accounts
  amount DECIMAL(12, 2) NOT NULL,
  category TEXT, -- 'labor', 'materials', 'subcontractor', 'overhead'
  description TEXT,
  date DATE NOT NULL,
  invoice_id uuid REFERENCES invoices(id),
  created_at TIMESTAMP DEFAULT now()
);

CREATE INDEX cost_entries_project_id ON cost_entries(project_id);
CREATE INDEX cost_entries_date ON cost_entries(date);

-- =====================================================
-- Enable RLS (Row Level Security)
-- =====================================================

ALTER TABLE sync_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE alert_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE alert_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE time_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE cost_entries ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- RLS Policies
-- =====================================================

-- Users can only see their own sync logs
CREATE POLICY "sync_log_user_access" ON sync_log
  FOR SELECT USING (auth.uid() = user_id);

-- Users can only see/manage their own report templates
CREATE POLICY "report_templates_user_access" ON report_templates
  FOR SELECT USING (auth.uid() = owner_id OR is_public = TRUE);

CREATE POLICY "report_templates_user_manage" ON report_templates
  FOR UPDATE USING (auth.uid() = owner_id);

CREATE POLICY "report_templates_user_create" ON report_templates
  FOR INSERT WITH CHECK (auth.uid() = owner_id);

-- Alert access by project membership
CREATE POLICY "alert_configs_project_access" ON alert_configs
  FOR SELECT USING (
    auth.uid() = user_id OR
    EXISTS (SELECT 1 FROM projects WHERE id = alert_configs.project_id AND owner_id = auth.uid())
  );

-- Similar for other tables...
