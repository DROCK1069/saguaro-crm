/**
 * Project Photo Manager Component
 * Upload, organize, and link photos to project entities
 */

'use client';

import React, { useState, useRef } from 'react';
import { createClient } from '@supabase/supabase-js';

interface Photo {
  id: string;
  file_path: string;
  caption?: string;
  latitude?: number;
  longitude?: number;
  linked_to_entity?: string;
  linked_to_id?: string;
  created_at: string;
}

interface PhotoManagerProps {
  projectId: string;
  linkedEntity?: string;
  linkedEntityId?: string;
  onPhotosLoaded?: (photos: Photo[]) => void;
}

export default function ProjectPhotoManager({
  projectId,
  linkedEntity,
  linkedEntityId,
  onPhotosLoaded,
}: PhotoManagerProps) {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [caption, setCaption] = useState('');
  const [useGPS, setUseGPS] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize Supabase client
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  // Load photos on mount
  React.useEffect(() => {
    loadPhotos();
  }, [projectId, linkedEntity, linkedEntityId]);

  const loadPhotos = async () => {
    setLoading(true);
    setError(null);
    try {
      let query = supabase
        .from('project_photos')
        .select('*')
        .eq('project_id', projectId);

      if (linkedEntity && linkedEntityId) {
        query = query.eq('linked_to_entity', linkedEntity).eq('linked_to_id', linkedEntityId);
      }

      const { data, error: err } = await query.order('created_at', { ascending: false });

      if (err) throw err;
      setPhotos(data || []);
      onPhotosLoaded?.(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load photos');
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    setError(null);

    try {
      for (const file of Array.from(files)) {
        // Get current position if GPS enabled
        let latitude: number | undefined;
        let longitude: number | undefined;

        if (useGPS && navigator.geolocation) {
          const position = await new Promise<GeolocationCoordinates>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(
              pos => resolve(pos.coords),
              err => reject(err),
              { timeout: 5000 }
            );
          }).catch(() => null);

          if (position) {
            latitude = position.latitude;
            longitude = position.longitude;
          }
        }

        // Upload file to Supabase Storage
        const filename = `${projectId}/${Date.now()}_${file.name}`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('project-photos')
          .upload(filename, file);

        if (uploadError) throw uploadError;

        // Create photo record in database
        const { data: photoData, error: dbError } = await supabase
          .from('project_photos')
          .insert({
            project_id: projectId,
            file_path: uploadData.path,
            caption: caption || null,
            latitude: latitude || null,
            longitude: longitude || null,
            linked_to_entity: linkedEntity || null,
            linked_to_id: linkedEntityId || null,
          })
          .select()
          .single();

        if (dbError) throw dbError;

        // Add to local state
        setPhotos(prev => [photoData, ...prev]);
      }

      // Reset form
      setCaption('');
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleDeletePhoto = async (photoId: string, filePath: string) => {
    if (!confirm('Delete this photo?')) return;

    try {
      // Delete from storage
      await supabase.storage.from('project-photos').remove([filePath]);

      // Delete from database
      await supabase.from('project_photos').delete().eq('id', photoId);

      // Update local state
      setPhotos(prev => prev.filter(p => p.id !== photoId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete photo');
    }
  };

  const getPhotoUrl = (filePath: string) => {
    const { data } = supabase.storage.from('project-photos').getPublicUrl(filePath);
    return data.publicUrl;
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2 style={{ marginBottom: '20px' }}>Project Photos</h2>

      {error && (
        <div
          style={{
            padding: '12px',
            backgroundColor: '#fee2e2',
            color: '#991b1b',
            borderRadius: '4px',
            marginBottom: '16px',
          }}
        >
          {error}
        </div>
      )}

      {/* Upload Section */}
      <div
        style={{
          padding: '20px',
          backgroundColor: '#f9fafb',
          borderRadius: '4px',
          marginBottom: '20px',
          border: '1px solid #e5e7eb',
        }}
      >
        <h3 style={{ marginBottom: '16px' }}>Upload Photos</h3>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
          {/* Caption Input */}
          <div>
            <label style={{ display: 'block', marginBottom: '4px', fontWeight: '500' }}>
              Photo Caption (optional)
            </label>
            <input
              type="text"
              value={caption}
              onChange={e => setCaption(e.target.value)}
              placeholder="e.g., Foundation inspection, Day 3"
              style={{
                width: '100%',
                padding: '8px',
                border: '1px solid #d1d5db',
                borderRadius: '4px',
                boxSizing: 'border-box',
              }}
            />
          </div>

          {/* GPS Toggle */}
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: '8px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={useGPS}
                onChange={e => setUseGPS(e.target.checked)}
              />
              <span>Include GPS Location</span>
            </label>
          </div>
        </div>

        {/* File Input */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*"
          onChange={handleFileSelect}
          disabled={uploading}
          style={{ display: 'none' }}
        />

        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          style={{
            padding: '10px 20px',
            backgroundColor: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: uploading ? 'not-allowed' : 'pointer',
            opacity: uploading ? 0.6 : 1,
          }}
        >
          {uploading ? 'Uploading...' : 'Choose Photos'}
        </button>
      </div>

      {/* Photos Grid */}
      {loading ? (
        <p style={{ textAlign: 'center', color: '#6b7280' }}>Loading photos...</p>
      ) : photos.length === 0 ? (
        <p style={{ textAlign: 'center', color: '#6b7280' }}>No photos yet</p>
      ) : (
        <>
          <p style={{ marginBottom: '16px', color: '#6b7280' }}>
            {photos.length} photo{photos.length !== 1 ? 's' : ''}
          </p>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
              gap: '16px',
            }}
          >
            {photos.map(photo => (
              <div
                key={photo.id}
                style={{
                  border: '1px solid #e5e7eb',
                  borderRadius: '4px',
                  overflow: 'hidden',
                  backgroundColor: 'white',
                }}
              >
                {/* Photo Thumbnail */}
                <div
                  style={{
                    width: '100%',
                    height: '200px',
                    backgroundColor: '#f3f4f6',
                    position: 'relative',
                    overflow: 'hidden',
                  }}
                >
                  <img
                    src={getPhotoUrl(photo.file_path)}
                    alt={photo.caption || 'Project photo'}
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      cursor: 'pointer',
                    }}
                    onClick={() => window.open(getPhotoUrl(photo.file_path), '_blank')}
                  />
                </div>

                {/* Photo Info */}
                <div style={{ padding: '12px' }}>
                  {photo.caption && (
                    <p style={{ fontWeight: '500', marginBottom: '8px', fontSize: '14px' }}>
                      {photo.caption}
                    </p>
                  )}

                  <p style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>
                    {new Date(photo.created_at).toLocaleDateString()}
                  </p>

                  {photo.latitude && photo.longitude && (
                    <p style={{ fontSize: '12px', color: '#3b82f6', marginBottom: '8px' }}>
                      📍 {photo.latitude.toFixed(4)}, {photo.longitude.toFixed(4)}
                    </p>
                  )}

                  {photo.linked_to_entity && (
                    <p style={{ fontSize: '12px', backgroundColor: '#f0fdf4', padding: '4px', borderRadius: '2px', marginBottom: '8px' }}>
                      Linked to {photo.linked_to_entity} #{photo.linked_to_id}
                    </p>
                  )}

                  <button
                    onClick={() => handleDeletePhoto(photo.id, photo.file_path)}
                    style={{
                      width: '100%',
                      padding: '6px',
                      backgroundColor: '#ef4444',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '12px',
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
