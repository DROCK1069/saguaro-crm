/**
 * QuickBooks Integration Hook
 * React hook for OAuth2 auth flow and QB data sync
 */

'use client';

import { useState, useCallback, useEffect } from 'react';
import { getAuthUrl, syncInvoicesToSaguaro } from '@/lib/quickbooksClient';

interface UseQuickBooksReturn {
  isAuthenticating: boolean;
  isAuthenticated: boolean;
  isSyncing: boolean;
  error: string | null;
  startAuthentication: () => Promise<void>;
  syncData: () => Promise<void>;
  logout: () => void;
}

export function useQuickBooks(): UseQuickBooksReturn {
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Check if already authenticated on mount
  useEffect(() => {
    const token = sessionStorage.getItem('qb_access_token');
    setIsAuthenticated(!!token);
  }, []);

  const startAuthentication = useCallback(async () => {
    setIsAuthenticating(true);
    setError(null);

    try {
      const state = Math.random().toString(36).substring(7);
      sessionStorage.setItem('qb_state', state);

      const authUrl = getAuthUrl(state);
      const popup = window.open(authUrl, 'QB_Auth', 'width=600,height=700');

      if (!popup) {
        throw new Error('Failed to open authentication window');
      }

      // Listen for message from callback
      const handleMessage = (event: MessageEvent) => {
        if (event.origin !== window.location.origin) return;

        if (event.data.type === 'QB_AUTH_SUCCESS') {
          sessionStorage.setItem('qb_access_token', event.data.accessToken);
          sessionStorage.setItem('qb_realm_id', event.data.realmId);
          setIsAuthenticated(true);
          popup.close();
          window.removeEventListener('message', handleMessage);
        } else if (event.data.type === 'QB_AUTH_ERROR') {
          setError(event.data.error);
          popup.close();
          window.removeEventListener('message', handleMessage);
        }
      };

      window.addEventListener('message', handleMessage);

      // Timeout after 10 minutes
      const timeout = setTimeout(() => {
        setError('Authentication timeout');
        popup.close();
        window.removeEventListener('message', handleMessage);
      }, 10 * 60 * 1000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setIsAuthenticating(false);
    }
  }, []);

  const syncData = useCallback(async () => {
    const token = sessionStorage.getItem('qb_access_token');
    if (!token) {
      setError('Not authenticated with QuickBooks');
      return;
    }

    setIsSyncing(true);
    setError(null);

    try {
      // In a real app, this would get the authenticated DB connection
      // For now, we'll just log the sync request
      console.log('Syncing QB data to Saguaro...');

      // Call the API endpoint that handles the sync
      const response = await fetch('/api/integrations/quickbooks/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          accessToken: token,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Sync failed');
      }

      const result = await response.json();
      console.log('Sync complete:', result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sync failed');
    } finally {
      setIsSyncing(false);
    }
  }, []);

  const logout = useCallback(() => {
    sessionStorage.removeItem('qb_access_token');
    sessionStorage.removeItem('qb_realm_id');
    sessionStorage.removeItem('qb_state');
    setIsAuthenticated(false);
    setError(null);
  }, []);

  return {
    isAuthenticating,
    isAuthenticated,
    isSyncing,
    error,
    startAuthentication,
    syncData,
    logout,
  };
}
