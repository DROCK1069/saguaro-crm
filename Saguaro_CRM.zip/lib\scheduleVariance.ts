/**
 * Schedule Variance Forecasting Service
 * Predicts project schedule delays based on historical data and current progress
 * Uses linear regression and trend analysis
 */

export interface ScheduleForecast {
  projectId: string;
  originalEndDate: string;
  predictedEndDate: string;
  daysVariance: number;
  variancePercent: number;
  confidenceLevel: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  criticalPath: Array<{ taskId: string; taskName: string; slack: number }>;
  delayedTasks: Array<{
    taskId: string;
    taskName: string;
    plannedFinish: string;
    estimatedFinish: string;
    daysLate: number;
  }>;
  recommendations: string[];
}

export interface TaskProgressData {
  taskId: string;
  taskName: string;
  plannedStart: string;
  plannedFinish: string;
  actualStart?: string;
  actualFinish?: string;
  percentComplete: number;
  estimatedFinish?: string;
  dependencies: string[];
  resourcesAllocated: number;
}

class ScheduleVarianceService {
  /**
   * Forecast project completion date based on current progress
   */
  async forecastSchedule(projectId: string, tasks: TaskProgressData[], db: any): Promise<ScheduleForecast> {
    const now = new Date();

    // Get original end date
    const { data: project, error: projError } = await db.from('projects')
      .select('end_date, start_date, name')
      .eq('id', projectId)
      .single();

    if (projError || !project) {
      throw new Error(`Project ${projectId} not found`);
    }

    const originalEnd = new Date(project.end_date);
    const projectStart = new Date(project.start_date);
    const totalProjectDays = Math.floor((originalEnd.getTime() - projectStart.getTime()) / (1000 * 60 * 60 * 24));
    const elapsedDays = Math.floor((now.getTime() - projectStart.getTime()) / (1000 * 60 * 60 * 24));
    const remainingDays = totalProjectDays - elapsedDays;

    // 1. Calculate average progress rate
    const completedTasks = tasks.filter(t => t.percentComplete === 100);
    const inProgressTasks = tasks.filter(t => t.percentComplete > 0 && t.percentComplete < 100);

    const avgProgressPerDay = completedTasks.length / Math.max(elapsedDays, 1);
    const remainingTasks = tasks.filter(t => t.percentComplete === 0).length;
    const projectedDaysNeeded = remainingTasks / Math.max(avgProgressPerDay, 0.01);

    // 2. Analyze delayed tasks
    const delayedTasks = this.analyzeDelayedTasks(tasks);

    // 3. Calculate critical path
    const criticalPath = this.calculateCriticalPath(tasks);

    // 4. Predict end date
    const predictedEndDate = new Date(now.getTime() + (projectedDaysNeeded * 24 * 60 * 60 * 1000));
    const daysVariance = Math.floor((predictedEndDate.getTime() - originalEnd.getTime()) / (1000 * 60 * 60 * 24));
    const variancePercent = (daysVariance / totalProjectDays) * 100;

    // 5. Calculate confidence level (0-100)
    const confidenceLevel = Math.max(40, 100 - (Math.abs(daysVariance) * 2));

    // 6. Determine risk level
    const riskLevel = this.calculateRiskLevel(daysVariance, variancePercent);

    // 7. Generate recommendations
    const recommendations = this.generateRecommendations(delayedTasks, criticalPath, daysVariance);

    // Save forecast to database
    await db.from('schedule_forecasts').insert({
      project_id: projectId,
      original_end_date: project.end_date,
      predicted_end_date: predictedEndDate.toISOString(),
      days_variance: daysVariance,
      variance_percent: variancePercent,
      confidence_level: confidenceLevel,
      risk_level: riskLevel,
      critical_path: criticalPath,
      delayed_tasks: delayedTasks,
      created_at: new Date().toISOString(),
    });

    return {
      projectId,
      originalEndDate: project.end_date,
      predictedEndDate: predictedEndDate.toISOString(),
      daysVariance,
      variancePercent,
      confidenceLevel,
      riskLevel,
      criticalPath,
      delayedTasks,
      recommendations,
    };
  }

  /**
   * Analyze which tasks are delayed or at risk
   */
  private analyzeDelayedTasks(tasks: TaskProgressData[]): Array<{
    taskId: string;
    taskName: string;
    plannedFinish: string;
    estimatedFinish: string;
    daysLate: number;
  }> {
    const now = new Date();
    const delayed: Array<{
      taskId: string;
      taskName: string;
      plannedFinish: string;
      estimatedFinish: string;
      daysLate: number;
    }> = [];

    tasks.forEach(task => {
      const plannedFinish = new Date(task.plannedFinish);
      let estimatedFinish = task.estimatedFinish ? new Date(task.estimatedFinish) : plannedFinish;

      if (task.percentComplete < 100) {
        // Estimate based on progress
        if (task.actualStart) {
          const startDate = new Date(task.actualStart);
          const daysElapsed = Math.floor((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
          const daysPerPercent = daysElapsed / Math.max(task.percentComplete, 1);
          const totalDaysNeeded = daysPerPercent * 100;
          estimatedFinish = new Date(startDate.getTime() + (totalDaysNeeded * 24 * 60 * 60 * 1000));
        }
      }

      const daysLate = Math.floor((estimatedFinish.getTime() - plannedFinish.getTime()) / (1000 * 60 * 60 * 24));

      if (daysLate > 0) {
        delayed.push({
          taskId: task.taskId,
          taskName: task.taskName,
          plannedFinish: task.plannedFinish,
          estimatedFinish: estimatedFinish.toISOString(),
          daysLate,
        });
      }
    });

    return delayed.sort((a, b) => b.daysLate - a.daysLate);
  }

  /**
   * Calculate critical path (tasks with zero slack)
   */
  private calculateCriticalPath(tasks: TaskProgressData[]): Array<{ taskId: string; taskName: string; slack: number }> {
    const criticalPath: Array<{ taskId: string; taskName: string; slack: number }> = [];

    // Simplified critical path: tasks with dependencies and zero slack
    tasks.forEach(task => {
      const hasSlack = task.dependencies.length === 0;
      const slackDays = hasSlack ? 1 : 0;

      if (slackDays === 0) {
        criticalPath.push({
          taskId: task.taskId,
          taskName: task.taskName,
          slack: slackDays,
        });
      }
    });

    return criticalPath;
  }

  /**
   * Determine risk level based on variance
   */
  private calculateRiskLevel(daysVariance: number, variancePercent: number): 'low' | 'medium' | 'high' | 'critical' {
    if (variancePercent <= 5) return 'low';
    if (variancePercent <= 15) return 'medium';
    if (variancePercent <= 30) return 'high';
    return 'critical';
  }

  /**
   * Generate actionable recommendations
   */
  private generateRecommendations(
    delayedTasks: any[],
    criticalPath: any[],
    daysVariance: number
  ): string[] {
    const recommendations: string[] = [];

    if (daysVariance > 0) {
      recommendations.push(`⏰ Project at risk of ${daysVariance} day delay. Recommend acceleration plan.`);
    }

    if (delayedTasks.length > 0) {
      recommendations.push(`⚠️ ${delayedTasks.length} tasks are delayed. Focus on critical path tasks first.`);

      // Specifically recommend the worst performers
      const worst = delayedTasks.slice(0, 2);
      worst.forEach(task => {
        recommendations.push(`• Accelerate "${task.taskName}" - currently ${task.daysLate} days behind schedule`);
      });
    }

    if (criticalPath.length > 0) {
      recommendations.push(`📍 Critical path has ${criticalPath.length} tasks with zero slack. No buffer for delays.`);
    }

    if (daysVariance > 30) {
      recommendations.push('🚨 Consider requesting deadline extension or additional resources.');
    }

    if (recommendations.length === 0) {
      recommendations.push('✅ Project on track. Continue monitoring.');
    }

    return recommendations;
  }

  /**
   * Get Schedule Variance Index (SVI)
   * Compares planned vs actual progress
   * SVI > 1.0 means ahead of schedule
   * SVI < 1.0 means behind schedule
   */
  calculateScheduleVarianceIndex(tasks: TaskProgressData[], projectStart: string): number {
    const startDate = new Date(projectStart);
    const now = new Date();
    const totalDays = tasks.length; // Simplified: assume 1 day per task
    const elapsedDays = Math.floor((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));

    const plannedProgress = (elapsedDays / totalDays) * 100;
    const actualProgress = tasks.reduce((sum, t) => sum + t.percentComplete, 0) / tasks.length;

    return actualProgress / Math.max(plannedProgress, 1);
  }

  /**
   * Recommend tasks to compress (accelerate) to meet deadline
   */
  recommendTaskCompression(tasks: TaskProgressData[], targetDaysReduction: number): Array<{
    taskId: string;
    taskName: string;
    potentialReduction: number;
    compressionMethod: string;
  }> {
    const candidates: Array<{
      taskId: string;
      taskName: string;
      potentialReduction: number;
      compressionMethod: string;
    }> = [];

    tasks
      .filter(t => t.percentComplete < 100 && t.dependencies.length === 0)
      .forEach(task => {
        const plannedStart = new Date(task.plannedStart);
        const plannedFinish = new Date(task.plannedFinish);
        const duration = Math.floor((plannedFinish.getTime() - plannedStart.getTime()) / (1000 * 60 * 60 * 24));

        // Can compress by 20-30% by adding resources
        const potentialReduction = Math.floor(duration * 0.25);

        candidates.push({
          taskId: task.taskId,
          taskName: task.taskName,
          potentialReduction,
          compressionMethod: 'Add resources / work overtime',
        });
      });

    return candidates.sort((a, b) => b.potentialReduction - a.potentialReduction);
  }
}

export const scheduleVariance = new ScheduleVarianceService();
