/**
 * Alerts Configuration and Logging API
 * Register webhooks and log alert events
 */

import { createClient } from '@supabase/supabase-js';
import { NextRequest, NextResponse } from 'next/server';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co',
  process.env.SUPABASE_SERVICE_KEY || 'placeholder-key'
);

interface AlertConfig {
  projectId: string;
  type: 'slack' | 'teams';
  webhookUrl: string;
  channel?: string;
}

// POST /api/alerts/config - Register webhook config
export async function POST(request: NextRequest) {
  try {
    const auth = request.headers.get('authorization');
    if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const token = auth.slice(7);
    const {
      data: { user },
    } = await supabase.auth.getUser(token);
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body: AlertConfig = await request.json();

    // Permission check: user must be project owner/admin
    const { data: project } = await supabase
      .from('projects')
      .select('owner_id')
      .eq('id', body.projectId)
      .single();

    if (project?.owner_id !== user.id) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Validate webhook (basic test)
    try {
      const testPayload =
        body.type === 'slack'
          ? { text: 'Test message from Saguaro CRM' }
          : {
              summary: 'Test message from Saguaro CRM',
              sections: [{ text: 'Webhook configuration successful' }],
            };

      const res = await fetch(body.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(testPayload),
      });

      if (!res.ok) {
        return NextResponse.json({ error: 'Invalid webhook URL' }, { status: 400 });
      }
    } catch {
      return NextResponse.json({ error: 'Webhook URL unreachable' }, { status: 400 });
    }

    // Store config
    const { data, error } = await supabase
      .from('alert_configs')
      .upsert({
        project_id: body.projectId,
        type: body.type,
        webhook_url: body.webhookUrl,
        channel: body.channel,
        user_id: user.id,
        updated_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json({ config: data }, { status: 200 });
  } catch (error) {
    console.error('Alert config error:', error);
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}

// GET /api/alerts/config - Get configuration for project
export async function GET(request: NextRequest) {
  try {
    const auth = request.headers.get('authorization');
    if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const token = auth.slice(7);
    const {
      data: { user },
    } = await supabase.auth.getUser(token);
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { searchParams } = request.nextUrl;
    const projectId = searchParams.get('projectId');

    if (!projectId) {
      return NextResponse.json({ error: 'Missing projectId' }, { status: 400 });
    }

    const { data, error } = await supabase
      .from('alert_configs')
      .select('*')
      .eq('project_id', projectId)
      .eq('user_id', user.id);

    if (error) throw error;

    return NextResponse.json({ configs: data });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
