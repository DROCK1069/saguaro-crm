/**
 * Alert Configuration Component
 * Set up Slack and Teams webhook integrations
 */

'use client';

import React, { useState, useEffect } from 'react';

interface AlertConfig {
  id: string;
  type: 'slack' | 'teams';
  webhook_url: string;
  channel?: string;
  is_active: boolean;
}

interface AlertConfigManagerProps {
  projectId: string;
  token: string;
}

export default function AlertConfigManager({ projectId, token }: AlertConfigManagerProps) {
  const [configs, setConfigs] = useState<AlertConfig[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [addingConfig, setAddingConfig] = useState(false);

  const [formData, setFormData] = useState<{
    type: 'slack' | 'teams';
    webhookUrl: string;
    channel: string;
  }>({
    type: 'slack',
    webhookUrl: '',
    channel: '',
  });

  useEffect(() => {
    loadConfigs();
  }, [projectId]);

  const loadConfigs = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/alerts/config?projectId=${projectId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) throw new Error('Failed to load configurations');

      const data = await response.json();
      setConfigs(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load configurations');
    } finally {
      setLoading(false);
    }
  };

  const handleAddConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.webhookUrl) {
      setError('Webhook URL is required');
      return;
    }

    if (formData.type === 'slack' && !formData.channel) {
      setError('Slack channel is required');
      return;
    }

    try {
      const response = await fetch('/api/alerts/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          projectId,
          type: formData.type,
          webhookUrl: formData.webhookUrl,
          channel: formData.type === 'slack' ? formData.channel : undefined,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to add configuration');
      }

      const newConfig = await response.json();
      setConfigs(prev => [...prev, newConfig]);
      setFormData({ type: 'slack', webhookUrl: '', channel: '' });
      setAddingConfig(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add configuration');
    }
  };

  const handleDeleteConfig = async (configId: string) => {
    if (!confirm('Delete this alert configuration?')) return;

    try {
      const response = await fetch(`/api/alerts/config/${configId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) throw new Error('Failed to delete configuration');

      setConfigs(prev => prev.filter(c => c.id !== configId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete configuration');
    }
  };

  const handleToggleActive = async (configId: string, currentState: boolean) => {
    try {
      const response = await fetch(`/api/alerts/config/${configId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ is_active: !currentState }),
      });

      if (!response.ok) throw new Error('Failed to update configuration');

      setConfigs(prev =>
        prev.map(c => (c.id === configId ? { ...c, is_active: !currentState } : c))
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update configuration');
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px' }}>
      <h2 style={{ marginBottom: '20px' }}>Alert Integrations</h2>

      {error && (
        <div
          style={{
            padding: '12px',
            backgroundColor: '#fee2e2',
            color: '#991b1b',
            borderRadius: '4px',
            marginBottom: '16px',
          }}
        >
          {error}
        </div>
      )}

      {/* Existing Configurations */}
      {loading ? (
        <p style={{ color: '#6b7280' }}>Loading configurations...</p>
      ) : configs.length === 0 ? (
        <p style={{ color: '#6b7280', marginBottom: '20px' }}>No alert integrations configured</p>
      ) : (
        <div style={{ marginBottom: '20px' }}>
          <h3 style={{ marginBottom: '12px' }}>Active Integrations</h3>
          <div style={{ display: 'grid', gap: '12px' }}>
            {configs.map(config => (
              <div
                key={config.id}
                style={{
                  padding: '16px',
                  border: '1px solid #e5e7eb',
                  borderRadius: '4px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  backgroundColor: config.is_active ? '#f0fdf4' : '#f9fafb',
                }}
              >
                <div>
                  <h4 style={{ margin: '0 0 4px 0' }}>
                    {config.type === 'slack' ? '💬 Slack' : '🔔 Teams'}
                  </h4>
                  <p style={{ margin: '0 0 4px 0', fontSize: '12px', color: '#6b7280' }}>
                    {config.channel && `Channel: #${config.channel}`}
                  </p>
                  <p style={{ margin: '0', fontSize: '12px', color: '#6b7280' }}>
                    {config.webhook_url.substring(0, 60)}...
                  </p>
                </div>

                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => handleToggleActive(config.id, config.is_active)}
                    style={{
                      padding: '6px 12px',
                      backgroundColor: config.is_active ? '#10b981' : '#9ca3af',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '12px',
                    }}
                  >
                    {config.is_active ? '✓ Active' : '○ Inactive'}
                  </button>

                  <button
                    onClick={() => handleDeleteConfig(config.id)}
                    style={{
                      padding: '6px 12px',
                      backgroundColor: '#ef4444',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '12px',
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add New Configuration */}
      {!addingConfig ? (
        <button
          onClick={() => setAddingConfig(true)}
          style={{
            padding: '10px 20px',
            backgroundColor: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          + Add Integration
        </button>
      ) : (
        <div
          style={{
            padding: '20px',
            backgroundColor: '#f9fafb',
            borderRadius: '4px',
            border: '1px solid #e5e7eb',
          }}
        >
          <h3 style={{ marginBottom: '16px' }}>Add Alert Integration</h3>

          <form onSubmit={handleAddConfig}>
            {/* Type Select */}
            <div style={{ marginBottom: '16px' }}>
              <label style={{ display: 'block', marginBottom: '4px', fontWeight: '500' }}>
                Integration Type
              </label>
              <select
                value={formData.type}
                onChange={e => setFormData(prev => ({ ...prev, type: e.target.value as 'slack' | 'teams' }))}
                style={{
                  width: '100%',
                  padding: '8px',
                  border: '1px solid #d1d5db',
                  borderRadius: '4px',
                  boxSizing: 'border-box',
                }}
              >
                <option value="slack">Slack</option>
                <option value="teams">Microsoft Teams</option>
              </select>
            </div>

            {/* Channel (Slack only) */}
            {formData.type === 'slack' && (
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', marginBottom: '4px', fontWeight: '500' }}>
                  Slack Channel (without #)
                </label>
                <input
                  type="text"
                  value={formData.channel}
                  onChange={e => setFormData(prev => ({ ...prev, channel: e.target.value }))}
                  placeholder="e.g., project-alerts"
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: '1px solid #d1d5db',
                    borderRadius: '4px',
                    boxSizing: 'border-box',
                  }}
                />
              </div>
            )}

            {/* Webhook URL */}
            <div style={{ marginBottom: '16px' }}>
              <label style={{ display: 'block', marginBottom: '4px', fontWeight: '500' }}>
                Webhook URL
              </label>
              <input
                type="url"
                value={formData.webhookUrl}
                onChange={e => setFormData(prev => ({ ...prev, webhookUrl: e.target.value }))}
                placeholder={
                  formData.type === 'slack'
                    ? 'https://hooks.slack.com/services/...'
                    : 'https://outlook.webhook.office.com/...'
                }
                style={{
                  width: '100%',
                  padding: '8px',
                  border: '1px solid #d1d5db',
                  borderRadius: '4px',
                  boxSizing: 'border-box',
                  fontFamily: 'monospace',
                  fontSize: '12px',
                }}
              />
              <p style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>
                {formData.type === 'slack'
                  ? 'Get this from Slack App settings > Incoming Webhooks'
                  : 'Get this from Teams connector configuration'}
              </p>
            </div>

            {/* Action Buttons */}
            <div style={{ display: 'flex', gap: '12px' }}>
              <button
                type="submit"
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#10b981',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
              >
                Save Integration
              </button>

              <button
                type="button"
                onClick={() => setAddingConfig(false)}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#9ca3af',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                }}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Alert Types Info */}
      <div style={{ marginTop: '32px', padding: '16px', backgroundColor: '#f0f9ff', borderRadius: '4px' }}>
        <h3 style={{ marginBottom: '12px' }}>Alert Types</h3>
        <ul style={{ margin: '0', paddingLeft: '20px', fontSize: '14px' }}>
          <li>📋 Overdue RFIs (7+ days late)</li>
          <li>💳 Unpaid Invoices (past due date)</li>
          <li>⏰ Delayed Tasks (incomplete past finish date)</li>
          <li>📊 Budget Variance Alerts (cost overruns)</li>
        </ul>
      </div>
    </div>
  );
}
