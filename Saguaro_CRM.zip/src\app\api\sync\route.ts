/**
 * Offline Sync API Endpoint
 * Receives queued operations from offline-first clients
 * Applies them to the database with full ACID guarantees
 */

import { createClient } from '@supabase/supabase-js';
import { NextRequest, NextResponse } from 'next/server';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co',
  process.env.SUPABASE_SERVICE_KEY || 'placeholder-key'
);

interface SyncPayload {
  id: string;
  entity: string;
  action: 'create' | 'update' | 'delete';
  data: Record<string, any>;
  timestamp: number;
}

export async function POST(request: NextRequest) {
  try {
    // Validate auth
    const auth = request.headers.get('authorization');
    if (!auth || !auth.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const token = auth.slice(7);
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const payload: SyncPayload = await request.json();

    // Map entity types to table names
    const tableMap: Record<string, string> = {
      rfi: 'rfis',
      invoice: 'invoices',
      task: 'schedule_tasks',
      issue: 'field_issues',
      time_entry: 'time_entries',
    };

    const tableName = tableMap[payload.entity];
    if (!tableName) {
      return NextResponse.json({ error: 'Invalid entity type' }, { status: 400 });
    }

    let result;
    const timestamp = new Date().toISOString();

    switch (payload.action) {
      case 'create':
        {
          const { data, error } = await supabase
            .from(tableName)
            .insert({
              ...payload.data,
              created_at: timestamp,
              updated_at: timestamp,
              user_id: user.id,
            })
            .select()
            .single();

          if (error) throw error;
          result = data;
        }
        break;

      case 'update':
        {
          // Check for conflict (server timestamp > local timestamp)
          const { data: existing, error: getError } = await supabase
            .from(tableName)
            .select('updated_at')
            .eq('id', payload.data.id)
            .single();

          if (getError) throw getError;

          if (existing && new Date(existing.updated_at).getTime() > payload.timestamp) {
            // Conflict: server is newer
            return NextResponse.json(
              { error: 'Conflict', server: existing, timestamp: existing.updated_at },
              { status: 409 }
            );
          }

          const { data, error } = await supabase
            .from(tableName)
            .update({
              ...payload.data,
              updated_at: timestamp,
            })
            .eq('id', payload.data.id)
            .select()
            .single();

          if (error) throw error;
          result = data;
        }
        break;

      case 'delete':
        {
          const { error } = await supabase.from(tableName).delete().eq('id', payload.data.id);
          if (error) throw error;
          result = { id: payload.data.id, deleted: true };
        }
        break;

      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }

    // Log sync for audit trail
    await supabase.from('sync_log').insert({
      user_id: user.id,
      entity: payload.entity,
      action: payload.action,
      entity_id: payload.data.id,
      local_timestamp: payload.timestamp,
      server_timestamp: new Date(timestamp).getTime(),
      status: 'synced',
    });

    return NextResponse.json({ success: true, data: result }, { status: 200 });
  } catch (error) {
    console.error('Sync error:', error);
    return NextResponse.json({ error: 'Sync failed', details: String(error) }, { status: 500 });
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}
