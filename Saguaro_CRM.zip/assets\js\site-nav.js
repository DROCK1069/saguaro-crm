// Load the site nav fragment and wire up mobile toggle
(function(){
  function insertNav() {
    var placeholder = document.getElementById('site-nav-placeholder');
    if (!placeholder) return;
    fetch('fragments/site-nav.html').then(function(r){ return r.text(); }).then(function(html){
      placeholder.innerHTML = html;
      wireNav();
    }).catch(function(){ /* silent fallback */ });
  }

  function wireNav(){
    var nav = document.querySelector('.site-nav');
    if (!nav) return;
    var hh = nav.querySelector('.hamburger');
    var mobile = nav.querySelector('.mobile-menu');
    var links = nav.querySelectorAll('.links a');
    var skip = nav.querySelector('.skip-link');
    if (hh && mobile) {
      // ensure ids/controls
      if (!mobile.id) mobile.id = 'site-mobile-menu';
      hh.setAttribute('aria-controls', mobile.id);
      hh.addEventListener('click', function(){
        var open = mobile.classList.toggle('open');
        mobile.setAttribute('aria-hidden', (!open).toString());
        hh.setAttribute('aria-expanded', open.toString());
        if (open) {
          // move focus into first mobile link
          var mFirst = mobile.querySelector('a'); if (mFirst) mFirst.focus();
        }
      });
      // keyboard: Enter/Space toggles
      hh.addEventListener('keydown', function(e){
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); hh.click(); }
        if (e.key === 'Escape') { mobile.classList.remove('open'); mobile.setAttribute('aria-hidden','true'); hh.setAttribute('aria-expanded','false'); hh.focus(); }
      });
    }
    // mark active link by URL
    var path = location.pathname || '#';
    links.forEach(function(a, idx){
      try{ if (a.getAttribute('href') === path) a.setAttribute('aria-current','page'); }catch(e){}
      // keyboard navigation: arrow left/right
      a.addEventListener('keydown', function(e){
        if (e.key === 'ArrowRight') { e.preventDefault(); var next = links[(idx+1)%links.length]; if (next) next.focus(); }
        if (e.key === 'ArrowLeft') { e.preventDefault(); var prev = links[(idx-1+links.length)%links.length]; if (prev) prev.focus(); }
        if (e.key === 'Enter' || e.key === ' ') { /* let link activate naturally */ }
      });
      // set click behavior to update aria-current and close mobile if open
      a.addEventListener('click', function(){ links.forEach(function(x){ x.removeAttribute('aria-current'); }); a.setAttribute('aria-current','page'); if (mobile && mobile.classList.contains('open')) { mobile.classList.remove('open'); mobile.setAttribute('aria-hidden','true'); if (hh) hh.setAttribute('aria-expanded','false'); } });
    });

    // skip-link: move focus to main content
    if (skip) {
      skip.addEventListener('click', function(e){
        var main = document.getElementById('main-content');
        if (main) { e.preventDefault(); main.setAttribute('tabindex','-1'); main.focus(); main.removeAttribute('tabindex'); }
      });
    }
    // allow Escape to close mobile menu from document
    document.addEventListener('keydown', function(e){ if (e.key === 'Escape' && mobile && mobile.classList.contains('open')) { mobile.classList.remove('open'); mobile.setAttribute('aria-hidden','true'); if (hh) hh.setAttribute('aria-expanded','false'); hh && hh.focus(); } });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', insertNav);
  else insertNav();
})();
