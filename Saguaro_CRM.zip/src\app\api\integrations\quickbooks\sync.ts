/**
 * QuickBooks Sync Endpoint
 * Syncs QB data to Saguaro and checks for forecasting alerts
 */

import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { createQBClient } from '@/lib/quickbooksClient';
import { forecastBudget, rankProjectsByRisk } from '@/lib/predictiveAnalytics';
import { sendSlackAlert, sendTeamsAlert } from '@/lib/alertService';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co',
  process.env.SUPABASE_SERVICE_KEY || 'placeholder-key'
);

export async function POST(request: NextRequest) {
  try {
    // Get auth
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const token = authHeader.substring(7);
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const { projectId, accessToken, realmId } = await request.json();

    if (!projectId || !accessToken) {
      return NextResponse.json(
        { error: 'Missing projectId or accessToken' },
        { status: 400 }
      );
    }

    // Verify project ownership
    const { data: project, error: projectError } = await supabase
      .from('projects')
      .select('id')
      .eq('id', projectId)
      .eq('owner_id', user.id)
      .single();

    if (projectError || !project) {
      return NextResponse.json(
        { error: 'Project not found or not owned by user' },
        { status: 403 }
      );
    }

    // Initialize QB client
    const qbClient = createQBClient(
      process.env.QUICKBOOKS_CLIENT_ID!,
      process.env.QUICKBOOKS_CLIENT_SECRET!,
      process.env.QUICKBOOKS_REDIRECT_URI!
    );

    // Sync QB data to Saguaro
    const syncResult = {
      invoices: 0,
      expenses: 0,
      chartOfAccounts: 0,
    };

    // 1. Sync invoices
    try {
      const invoices = await qbClient.getInvoices();
      for (const invoice of invoices) {
        await supabase.from('invoices').upsert(
          {
            project_id: projectId,
            qb_invoice_id: invoice.id,
            invoice_number: invoice.docNumber,
            total: invoice.totalAmt || 0,
            status: 'draft',
            due_date: invoice.dueDate,
            client_name: invoice.customerRef,
            synced_from_qb: true,
          },
          { onConflict: 'qb_invoice_id' }
        );
      }
      syncResult.invoices = invoices.length;
    } catch (err) {
      console.error('Failed to sync invoices:', err);
    }

    // 2. Sync expenses
    try {
      const expenses = await qbClient.getExpenses();
      for (const expense of expenses) {
        await supabase.from('cost_entries').insert({
          project_id: projectId,
          amount: expense.TotalAmt || 0,
          category: 'expense',
          description: expense.DocNumber,
          date: expense.TxnDate,
        });
      }
      syncResult.expenses = expenses.length;
    } catch (err) {
      console.error('Failed to sync expenses:', err);
    }

    // 3. Sync chart of accounts
    try {
      const coa = await qbClient.getChartOfAccounts();
      // Store in project settings or separate table as needed
      syncResult.chartOfAccounts = coa.length;
    } catch (err) {
      console.error('Failed to sync chart of accounts:', err);
    }

    // 4. Check budget forecasts and send alerts
    try {
      const { data: costEntries } = await supabase
        .from('cost_entries')
        .select('*')
        .eq('project_id', projectId)
        .order('date', { ascending: true });

      if (costEntries && costEntries.length > 3) {
        // Get project details
        const { data: proj } = await supabase
          .from('projects')
          .select('*')
          .eq('id', projectId)
          .single();

        if (proj) {
          const costData = costEntries.map(c => ({
            date: c.date || new Date().toISOString(),
            amount: c.amount || 0
          }));
          const forecast = await forecastBudget(
            projectId,
            proj.value || 100000,
            costData,
            proj.deadline || new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString()
          );

          // Send alert if risk is high
          if (forecast && forecast.riskScore >= 50) {
            const { data: configs } = await supabase
              .from('alert_configs')
              .select('*')
              .eq('project_id', projectId)
              .eq('is_active', true);

            if (configs) {
              const severity =
                forecast.riskScore >= 75 ? 'critical' : 'warning';

              for (const config of configs) {
                if (config.type === 'slack') {
                  await sendSlackAlert(projectId, {
                    severity: forecast.riskScore >= 75 ? 'critical' : 'warning',
                    title: `⚠️ Budget Alert: ${proj.name}`,
                    description: `Project budget variance: ${forecast.variancePercent?.toFixed(1) || '0'}%`,
                    entity: 'project',
                    entityId: projectId,
                    actionUrl: `/project/${projectId}`,
                  });
                } else if (config.type === 'teams') {
                  await sendTeamsAlert(projectId, {
                    severity: forecast.riskScore >= 75 ? 'critical' : 'warning',
                    title: `⚠️ Budget Alert: ${proj.name}`,
                    description: `Project budget variance: ${forecast.variancePercent?.toFixed(1) || '0'}%`,
                    entity: 'project',
                    entityId: projectId,
                    actionUrl: `/project/${projectId}`,
                  });
                }
              }
            }
          }
        }
      }
    } catch (err) {
      console.error('Failed to check budget forecast:', err);
    }

    return NextResponse.json({
      success: true,
      synced: syncResult,
      message: 'QB sync completed',
    });
  } catch (error) {
    console.error('QB sync error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal error' },
      { status: 500 }
    );
  }
}
