-- Phase 2 Database Migration - Schedule Forecasting & Photo OCR
-- Creates tables for advanced analytics and image processing
-- 
-- Tables:
-- 1. schedule_forecasts - Project completion predictions
-- 2. photo_ocr - Extracted text and issue detection from photos
-- 3. schedule_analytics - Task-level variance tracking

-- Table: schedule_forecasts
-- Stores schedule variance predictions and critical path analysis
CREATE TABLE IF NOT EXISTS schedule_forecasts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  
  -- Forecast data
  original_end_date TIMESTAMP WITH TIME ZONE NOT NULL,
  predicted_end_date TIMESTAMP WITH TIME ZONE NOT NULL,
  days_variance INTEGER NOT NULL,
  variance_percent DECIMAL(5, 2) NOT NULL,
  
  -- Confidence and risk assessment
  confidence_level DECIMAL(5, 2) NOT NULL CHECK (confidence_level >= 0 AND confidence_level <= 100),
  risk_level VARCHAR(20) NOT NULL CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
  
  -- Detailed analysis as JSON
  critical_path JSONB NOT NULL DEFAULT '[]',
  delayed_tasks JSONB NOT NULL DEFAULT '[]',
  recommendations TEXT[] NOT NULL DEFAULT '{}',
  
  -- Metadata
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  
  -- Indexes for fast lookups
  CONSTRAINT schedule_forecasts_project_id_idx UNIQUE(project_id, created_at)
);

CREATE INDEX IF NOT EXISTS idx_schedule_forecasts_project 
  ON schedule_forecasts(project_id);
CREATE INDEX IF NOT EXISTS idx_schedule_forecasts_risk 
  ON schedule_forecasts(risk_level) 
  WHERE risk_level IN ('high', 'critical');

-- Table: photo_ocr
-- Stores OCR extraction results and detected issues from construction photos
CREATE TABLE IF NOT EXISTS photo_ocr (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  photo_id UUID NOT NULL REFERENCES project_photos(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  
  -- Extracted content
  extracted_text TEXT NOT NULL,
  
  -- Structured detections as JSON arrays
  measurements JSONB NOT NULL DEFAULT '[]',
  detected_issues JSONB NOT NULL DEFAULT '[]',
  detected_objects JSONB NOT NULL DEFAULT '[]',
  
  -- AI-generated insights
  insights TEXT,
  
  -- Processing metrics
  processing_time_ms INTEGER NOT NULL,
  confidence_score DECIMAL(3, 2) DEFAULT 0.85,
  
  -- Metadata
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_photo_ocr_photo 
  ON photo_ocr(photo_id);
CREATE INDEX IF NOT EXISTS idx_photo_ocr_project 
  ON photo_ocr(project_id);
CREATE INDEX IF NOT EXISTS idx_photo_ocr_created 
  ON photo_ocr(created_at DESC);

-- Table: schedule_analytics
-- Task-level schedule variance and performance tracking
CREATE TABLE IF NOT EXISTS schedule_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  
  -- Planned vs Actual
  planned_start TIMESTAMP WITH TIME ZONE NOT NULL,
  planned_finish TIMESTAMP WITH TIME ZONE NOT NULL,
  actual_start TIMESTAMP WITH TIME ZONE,
  actual_finish TIMESTAMP WITH TIME ZONE,
  
  -- Performance metrics
  days_variance INTEGER,
  variance_percent DECIMAL(5, 2),
  schedule_variance_index DECIMAL(5, 2),
  
  -- Predictions
  predicted_finish TIMESTAMP WITH TIME ZONE,
  finish_confidence DECIMAL(3, 2) DEFAULT 0.85,
  
  -- Status
  status VARCHAR(50) CHECK (status IN ('on-track', 'at-risk', 'behind', 'ahead')),
  last_updated TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  
  -- Metadata
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_schedule_analytics_task 
  ON schedule_analytics(task_id);
CREATE INDEX IF NOT EXISTS idx_schedule_analytics_project 
  ON schedule_analytics(project_id);
CREATE INDEX IF NOT EXISTS idx_schedule_analytics_status 
  ON schedule_analytics(status);

-- Add JSON Columns to existing tables for backwards compatibility

-- Add annotations column to project_photos if not exists
ALTER TABLE project_photos
ADD COLUMN IF NOT EXISTS annotations JSONB DEFAULT '[]';

-- Add phase_2_features column to projects for feature flags
ALTER TABLE projects
ADD COLUMN IF NOT EXISTS phase_2_features JSONB DEFAULT '{
  "slack_integration": false,
  "photo_ocr": false,
  "schedule_forecasting": false,
  "photo_annotations": false
}';

-- Indexes for JSON querying
CREATE INDEX IF NOT EXISTS idx_project_photos_annotations
  ON project_photos USING GIN (annotations);

CREATE INDEX IF NOT EXISTS idx_projects_phase_2_features
  ON projects USING GIN (phase_2_features);

-- Row-Level Security (RLS) Policies

-- Enable RLS on schedule_forecasts
ALTER TABLE schedule_forecasts ENABLE ROW LEVEL SECURITY;

CREATE POLICY schedule_forecasts_select ON schedule_forecasts
  FOR SELECT
  USING (
    (SELECT auth.uid()) IN (
      SELECT user_id FROM project_access
      WHERE project_id = schedule_forecasts.project_id
    )
  );

CREATE POLICY schedule_forecasts_insert ON schedule_forecasts
  FOR INSERT
  WITH CHECK (
    (SELECT auth.uid()) IN (
      SELECT user_id FROM project_access
      WHERE project_id = schedule_forecasts.project_id
        AND role IN ('admin', 'manager')
    )
  );

-- Enable RLS on photo_ocr
ALTER TABLE photo_ocr ENABLE ROW LEVEL SECURITY;

CREATE POLICY photo_ocr_select ON photo_ocr
  FOR SELECT
  USING (
    (SELECT auth.uid()) IN (
      SELECT user_id FROM project_access
      WHERE project_id = photo_ocr.project_id
    )
  );

CREATE POLICY photo_ocr_insert ON photo_ocr
  FOR INSERT
  WITH CHECK (
    (SELECT auth.uid()) IN (
      SELECT user_id FROM project_access
      WHERE project_id = photo_ocr.project_id
    )
  );

-- Enable RLS on schedule_analytics
ALTER TABLE schedule_analytics ENABLE ROW LEVEL SECURITY;

CREATE POLICY schedule_analytics_select ON schedule_analytics
  FOR SELECT
  USING (
    (SELECT auth.uid()) IN (
      SELECT user_id FROM project_access
      WHERE project_id = schedule_analytics.project_id
    )
  );

CREATE POLICY schedule_analytics_insert ON schedule_analytics
  FOR INSERT
  WITH CHECK (
    (SELECT auth.uid()) IN (
      SELECT user_id FROM project_access
      WHERE project_id = schedule_analytics.project_id
    )
  );

-- Triggers for updated_at columns
CREATE OR REPLACE FUNCTION update_schedule_forecasts_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER schedule_forecasts_update_timestamp
  BEFORE UPDATE ON schedule_forecasts
  FOR EACH ROW
  EXECUTE FUNCTION update_schedule_forecasts_timestamp();

CREATE OR REPLACE FUNCTION update_photo_ocr_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER photo_ocr_update_timestamp
  BEFORE UPDATE ON photo_ocr
  FOR EACH ROW
  EXECUTE FUNCTION update_photo_ocr_timestamp();

CREATE OR REPLACE FUNCTION update_schedule_analytics_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER schedule_analytics_update_timestamp
  BEFORE UPDATE ON schedule_analytics
  FOR EACH ROW
  EXECUTE FUNCTION update_schedule_analytics_timestamp();
