/**
 * Reports API Endpoints
 * Create, retrieve, and export custom reports
 */

import { createClient } from '@supabase/supabase-js';
import { NextRequest, NextResponse } from 'next/server';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co',
  process.env.SUPABASE_SERVICE_KEY || 'placeholder-key'
);

// GET /api/reports/templates - Retrieve all report templates for user
export async function GET(request: NextRequest) {
  try {
    const auth = request.headers.get('authorization');
    if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const token = auth.slice(7);
    const {
      data: { user },
    } = await supabase.auth.getUser(token);
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { data, error } = await supabase
      .from('report_templates')
      .select('*')
      .or(`owner_id.eq.${user.id},is_public.eq.true`)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return NextResponse.json({ templates: data });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}

// POST /api/reports/templates - Create a new report template
export async function POST(request: NextRequest) {
  if (request.method === 'POST' && request.nextUrl.pathname.includes('/templates')) {
    try {
      const auth = request.headers.get('authorization');
      if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

      const token = auth.slice(7);
      const {
        data: { user },
      } = await supabase.auth.getUser(token);
      if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

      const body = await request.json();
      const { data, error } = await supabase
        .from('report_templates')
        .insert({
          ...body,
          owner_id: user.id,
          created_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (error) throw error;
      return NextResponse.json({ template: data }, { status: 201 });
    } catch (error) {
      return NextResponse.json({ error: String(error) }, { status: 500 });
    }
  }

  return NextResponse.json({ error: 'Method not allowed' }, { status: 405 });
}

// DELETE /api/reports/templates/[id]
export async function DELETE(request: NextRequest) {
  try {
    const auth = request.headers.get('authorization');
    if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const token = auth.slice(7);
    const {
      data: { user },
    } = await supabase.auth.getUser(token);
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const parts = request.nextUrl.pathname.split('/');
    const templateId = parts[parts.length - 1];

    // Verify ownership
    const { data: template } = await supabase
      .from('report_templates')
      .select('owner_id')
      .eq('id', templateId)
      .single();

    if (template?.owner_id !== user.id) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { error } = await supabase.from('report_templates').delete().eq('id', templateId);
    if (error) throw error;

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
