import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/supabase/admin';
import { geofencing } from '@/lib/geofencing';

/**
 * Geofencing & Location Tracking API
 * Handles geofence creation, location tracking, and auto clock-in/out
 * 
 * POST /api/geofencing/track - Submit location update
 * POST /api/geofencing/geofences - Create geofence
 * GET /api/geofencing/geofences - Get project geofences
 * GET /api/geofencing/summary - Get geofence usage summary
 */

interface LocationTrackingRequest {
  userId: string;
  taskId: string;
  latitude: number;
  longitude: number;
  accuracy: number;
}

interface CreateGeofenceRequest {
  projectId: string;
  locationName: string;
  latitude: number;
  longitude: number;
  radiusMeters?: number;
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const url = new URL(request.url);
    const pathname = url.pathname;

    const db = supabaseAdmin;
    const body = await request.json();

    // Route: POST /api/geofencing/track
    if (pathname.includes('/track')) {
      const { userId, taskId, latitude, longitude, accuracy }: LocationTrackingRequest = body;

      if (!userId || !taskId || latitude === undefined || longitude === undefined) {
        return NextResponse.json(
          { error: 'Missing required fields' },
          { status: 400 }
        );
      }

      // Track location
      const event = await geofencing.trackLocation(
        userId,
        taskId,
        latitude,
        longitude,
        accuracy || 20,
        db
      );

      return NextResponse.json(
        {
          success: true,
          event,
        },
        { status: 200 }
      );
    }

    // Route: POST /api/geofencing/geofences (create)
    if (pathname.includes('/geofences') && request.method === 'POST') {
      const { projectId, locationName, latitude, longitude, radiusMeters }: CreateGeofenceRequest = body;

      if (!projectId || !locationName || latitude === undefined || longitude === undefined) {
        return NextResponse.json(
          { error: 'Missing required fields' },
          { status: 400 }
        );
      }

      const geofence = await geofencing.createGeofence(
        projectId,
        locationName,
        latitude,
        longitude,
        radiusMeters || 100,
        db
      );

      return NextResponse.json(
        {
          success: true,
          data: geofence,
        },
        { status: 201 }
      );
    }

    return NextResponse.json(
      { error: 'Unknown endpoint' },
      { status: 404 }
    );
  } catch (error) {
    console.error('Geofencing API error:', error);
    return NextResponse.json(
      { error: 'Request processing failed' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    const userId = searchParams.get('userId');
    const url = new URL(request.url);
    const pathname = url.pathname;

    const db = supabaseAdmin;

    // Route: GET /api/geofencing/geofences?projectId=...
    if (pathname.includes('/geofences')) {
      if (!projectId) {
        return NextResponse.json(
          { error: 'Project ID required' },
          { status: 400 }
        );
      }

      const geofences = await geofencing.getProjectGeofences(projectId, db);

      return NextResponse.json(
        {
          success: true,
          data: geofences,
        },
        { status: 200 }
      );
    }

    // Route: GET /api/geofencing/summary?userId=...&projectId=...
    if (pathname.includes('/summary')) {
      if (!userId || !projectId) {
        return NextResponse.json(
          { error: 'User ID and Project ID required' },
          { status: 400 }
        );
      }

      const summary = await geofencing.generateGeofenceSummary(projectId, userId, db);

      return NextResponse.json(
        {
          success: true,
          data: summary,
        },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { error: 'Unknown endpoint' },
      { status: 404 }
    );
  } catch (error) {
    console.error('Geofencing GET error:', error);
    return NextResponse.json(
      { error: 'Request failed' },
      { status: 500 }
    );
  }
}
