/**
 * QuickBooks OAuth Callback Handler
 * Exchanges authorization code for access token
 */

import { NextRequest, NextResponse } from 'next/server';

const QB_TOKEN_URL = 'https://oauth.platform.intuit.com/oauth2/tokens';
const CLIENT_ID = process.env.QUICKBOOKS_CLIENT_ID;
const CLIENT_SECRET = process.env.QUICKBOOKS_CLIENT_SECRET;
const REDIRECT_URI = process.env.QUICKBOOKS_REDIRECT_URI;

export async function POST(request: NextRequest) {
  try {
    const { code, realmId, state } = await request.json();

    if (!code || !realmId) {
      return NextResponse.json(
        { error: 'Missing code or realmId' },
        { status: 400 }
      );
    }

    // Exchange code for token
    const basicAuth = Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64');
    const response = await fetch(QB_TOKEN_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${basicAuth}`,
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: REDIRECT_URI!,
      }).toString(),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('QB token exchange failed:', error);
      return NextResponse.json(
        { error: 'Failed to exchange code for token' },
        { status: response.status }
      );
    }

    const tokenData = await response.json();

    // In a real app, store this securely (encrypted in DB)
    // For now, return to client (client stores in sessionStorage)
    return NextResponse.json({
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token,
      expiresIn: tokenData.expires_in,
      realmId,
    });
  } catch (error) {
    console.error('QB callback error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal error' },
      { status: 500 }
    );
  }
}
