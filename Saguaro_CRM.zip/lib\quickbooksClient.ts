/**
 * QuickBooks Online OAuth & Sync Integration
 * Real OAuth2 flow, token refresh, and bidirectional data sync
 */

export interface QBAuthFlow {
  authUrl: string;
  clientId: string;
  redirectUri: string;
  realm: string;
}

export interface QBTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  realmId: string;
  obtainedAt: number;
}

export interface QBInvoice {
  id: string;
  docNumber: string;
  customerRef: string;
  totalAmt: number;
  txnDate: string;
  dueDate: string;
  line: Array<{ amount: number; description: string }>;
}

export interface QBAccount {
  id: string;
  name: string;
  accountType: string;
  currentBalance: number;
}

class QuickBooksClient {
  private clientId: string;
  private clientSecret: string;
  private redirectUri: string;
  private realm: string = '';
  private tokens: QBTokens | null = null;

  constructor(clientId: string, clientSecret: string, redirectUri: string) {
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.redirectUri = redirectUri;
  }

  getAuthUrl(state: string): string {
    const params = new URLSearchParams({
      client_id: this.clientId,
      response_type: 'code',
      scope: 'com.intuit.quickbooks.accounting',
      redirect_uri: this.redirectUri,
      state,
    });
    return `https://appcenter.intuit.com/connect/oauth2?${params}`;
  }

  async exchangeCodeForToken(code: string, realmId: string): Promise<QBTokens> {
    const basicAuth = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64');
    const res = await fetch('https://oauth.platform.intuit.com/oauth2/tokens', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${basicAuth}`,
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: this.redirectUri,
      }).toString(),
    });

    const data = await res.json();
    this.tokens = {
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      expiresIn: data.expires_in,
      realmId,
      obtainedAt: Date.now(),
    };
    this.realm = realmId;
    return this.tokens;
  }

  async refreshAccessToken(): Promise<QBTokens> {
    if (!this.tokens) throw new Error('No refresh token available');

    const basicAuth = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString('base64');
    const res = await fetch('https://oauth.platform.intuit.com/oauth2/tokens', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${basicAuth}`,
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: this.tokens.refreshToken,
      }).toString(),
    });

    const data = await res.json();
    this.tokens = {
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      expiresIn: data.expires_in,
      realmId: this.realm,
      obtainedAt: Date.now(),
    };
    return this.tokens;
  }

  async makeRequest(endpoint: string, method = 'GET', body?: any) {
    if (!this.tokens) throw new Error('Not authenticated');
    if (Date.now() - this.tokens.obtainedAt > this.tokens.expiresIn * 1000) {
      await this.refreshAccessToken();
    }

    const url = `https://quickbooks.api.intuit.com/v2/company/${this.realm}/${endpoint}`;
    const res = await fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${this.tokens.accessToken}`,
        'Content-Type': 'application/json',
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!res.ok) throw new Error(`QB API error: ${res.status}`);
    return res.json();
  }

  async getInvoices(): Promise<QBInvoice[]> {
    const result = await this.makeRequest('query?query=select * from Invoice');
    return result.QueryResponse.Invoice || [];
  }

  async getExpenses() {
    const result = await this.makeRequest('query?query=select * from Expense');
    return result.QueryResponse.Expense || [];
  }

  async getChartOfAccounts(): Promise<QBAccount[]> {
    const result = await this.makeRequest('query?query=select * from Account');
    return result.QueryResponse.Account || [];
  }

  async createBillFromInvoice(saguaroInvoice: any) {
    // Map Saguaro invoice to QB Bill
    const qbBill = {
      vendorRef: { value: saguaroInvoice.vendorId },
      txnDate: saguaroInvoice.dateCreated,
      dueDate: saguaroInvoice.dueDate,
      line: saguaroInvoice.items.map((item: any) => ({
        detailType: 'ExpenseLineDetail',
        amount: item.amount,
        description: item.description,
        expenseAccountRef: { value: item.accountId },
      })),
      docNumber: saguaroInvoice.id,
      currencyRef: { value: 'USD' },
    };
    return this.makeRequest('bill', 'POST', qbBill);
  }

  async syncInvoicesToSaguaro(db: any) {
    const invoices = await this.getInvoices();
    for (const invoice of invoices) {
      // Check if exists in Saguaro
      const existing = await db.from('invoices').select('*').eq('qb_id', invoice.id).single();
      if (!existing) {
        // Create in Saguaro
        await db.from('invoices').insert({
          qb_id: invoice.id,
          number: invoice.docNumber,
          amount: invoice.totalAmt,
          date_received: invoice.txnDate,
          due_date: invoice.dueDate,
          vendor: (invoice.customerRef as any)?.value || (invoice.customerRef as string),
          status: 'pending',
        });
      }
    }
  }

  setTokens(tokens: QBTokens) {
    this.tokens = tokens;
    this.realm = tokens.realmId;
  }

  getTokens(): QBTokens | null {
    return this.tokens;
  }
}

export function createQBClient(clientId: string, clientSecret: string, redirectUri: string) {
  return new QuickBooksClient(clientId, clientSecret, redirectUri);
}

// Convenience functions for OAuth flow
const _defaultClient = createQBClient(
  process.env.QUICKBOOKS_CLIENT_ID || '',
  process.env.QUICKBOOKS_CLIENT_SECRET || '',
  process.env.QUICKBOOKS_REDIRECT_URI || ''
);

export function getAuthUrl(state: string): string {
  return _defaultClient.getAuthUrl(state);
}

export async function syncInvoicesToSaguaro(db: any): Promise<void> {
  return _defaultClient.syncInvoicesToSaguaro(db);
}
