/**
 * QuickBooks Integration Component
 * UI for OAuth2 auth, invoice sync, and account linking
 */

'use client';

import React from 'react';
import { useQuickBooks } from '@/hooks/useQuickBooks';

interface QBIntegrationProps {
  projectId: string;
  onSyncComplete?: () => void;
}

export default function QuickBooksIntegration({ projectId, onSyncComplete }: QBIntegrationProps) {
  const {
    isAuthenticating,
    isAuthenticated,
    isSyncing,
    error,
    startAuthentication,
    syncData,
    logout,
  } = useQuickBooks();

  const handleConnect = async () => {
    await startAuthentication();
  };

  const handleSync = async () => {
    await syncData();
    onSyncComplete?.();
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px' }}>
      <h2 style={{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
        💼 QuickBooks Integration
      </h2>

      {error && (
        <div
          style={{
            padding: '12px',
            backgroundColor: '#fee2e2',
            color: '#991b1b',
            borderRadius: '4px',
            marginBottom: '16px',
          }}
        >
          {error}
        </div>
      )}

      {isAuthenticated ? (
        <div
          style={{
            padding: '16px',
            backgroundColor: '#f0fdf4',
            border: '2px solid #10b981',
            borderRadius: '4px',
          }}
        >
          <div style={{ marginBottom: '16px' }}>
            <h3 style={{ margin: '0 0 8px 0' }}>✓ Connected</h3>
            <p style={{ margin: '0', color: '#6b7280', fontSize: '14px' }}>
              Your QuickBooks account is connected. Sync invoices and expenses to Saguaro.
            </p>
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '12px',
              marginBottom: '16px',
            }}
          >
            <button
              onClick={handleSync}
              disabled={isSyncing}
              style={{
                padding: '10px 16px',
                backgroundColor: '#3b82f6',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: isSyncing ? 'not-allowed' : 'pointer',
                opacity: isSyncing ? 0.6 : 1,
                fontWeight: '500',
              }}
            >
              {isSyncing ? 'Syncing...' : '🔄 Sync Now'}
            </button>

            <button
              onClick={logout}
              style={{
                padding: '10px 16px',
                backgroundColor: '#ef4444',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontWeight: '500',
              }}
            >
              Disconnect
            </button>
          </div>

          <div
            style={{
              padding: '12px',
              backgroundColor: '#f0f9ff',
              borderRadius: '4px',
              fontSize: '13px',
              color: '#6b7280',
            }}
          >
            <p style={{ margin: '0 0 8px 0', fontWeight: '500' }}>Auto-Sync Features:</p>
            <ul style={{ margin: '0', paddingLeft: '20px' }}>
              <li>📋 Pull invoices from QuickBooks</li>
              <li>💰 Sync expense entries</li>
              <li>📊 Map chart of accounts</li>
              <li>🔗 Link QB bills to Saguaro invoices</li>
            </ul>
          </div>
        </div>
      ) : (
        <div
          style={{
            padding: '16px',
            backgroundColor: '#f9fafb',
            border: '1px solid #e5e7eb',
            borderRadius: '4px',
          }}
        >
          <h3 style={{ margin: '0 0 12px 0' }}>Connect QuickBooks</h3>

          <p style={{ margin: '0 0 16px 0', color: '#6b7280', fontSize: '14px' }}>
            Link your QuickBooks account to automatically sync invoices, expenses, and financial data.
          </p>

          <div
            style={{
              padding: '12px',
              backgroundColor: '#fef3c7',
              borderRadius: '4px',
              marginBottom: '16px',
              fontSize: '13px',
              color: '#78350f',
            }}
          >
            ⚠️ You'll be redirected to QuickBooks to authorize access. A popup will open for secure authentication.
          </div>

          <button
            onClick={handleConnect}
            disabled={isAuthenticating}
            style={{
              width: '100%',
              padding: '12px',
              backgroundColor: '#059669',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: isAuthenticating ? 'not-allowed' : 'pointer',
              opacity: isAuthenticating ? 0.6 : 1,
              fontWeight: '600',
              fontSize: '16px',
            }}
          >
            {isAuthenticating ? 'Connecting...' : '🔐 Connect QuickBooks'}
          </button>

          <div
            style={{
              marginTop: '16px',
              padding: '12px',
              backgroundColor: '#eff6ff',
              borderRadius: '4px',
              fontSize: '13px',
              color: '#1e40af',
            }}
          >
            <p style={{ margin: '0 0 8px 0', fontWeight: '500' }}>What we sync:</p>
            <ul style={{ margin: '0', paddingLeft: '20px' }}>
              <li>Invoices and estimates</li>
              <li>Bill payments and expenses</li>
              <li>Chart of accounts mapping</li>
              <li>Vendor and customer data</li>
            </ul>
          </div>
        </div>
      )}

      {/* OAuth Callback Handler */}
      <QBOAuthCallback />
    </div>
  );
}

/**
 * OAuth Callback Handler Component
 * Processes OAuth redirect when user returns from QB auth
 */
function QBOAuthCallback() {
  React.useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const state = urlParams.get('state');
    const realmId = urlParams.get('realmId');

    if (code && state && realmId) {
      // Verify state matches what we sent
      const savedState = sessionStorage.getItem('qb_state');

      if (savedState === state) {
        // Exchange code for token
        fetch('/api/integrations/quickbooks/callback', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code, realmId, state }),
        })
          .then(res => res.json())
          .then(data => {
            if (data.accessToken) {
              sessionStorage.setItem('qb_access_token', data.accessToken);
              sessionStorage.setItem('qb_realm_id', realmId);

              // Notify parent window and close this popup
              if (window.opener) {
                window.opener.postMessage(
                  { type: 'QB_AUTH_SUCCESS', accessToken: data.accessToken, realmId },
                  window.location.origin
                );
                window.close();
              } else {
                window.location.href = '/dashboard';
              }
            } else {
              throw new Error(data.error || 'Authentication failed');
            }
          })
          .catch(err => {
            if (window.opener) {
              window.opener.postMessage(
                { type: 'QB_AUTH_ERROR', error: err.message },
                window.location.origin
              );
            }
          });
      }

      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  return null;
}
