/**
 * Phase 3 Database Migration - Advanced Features
 * Creates tables for geofencing, white-label, commissions, and API v2
 * 
 * Tables:
 * 1. geofences - Job site location boundaries
 * 2. location_tracking - GPS location history
 * 3. geofence_alerts - User preferences for geofence notifications
 * 4. commission_structures - Commission rate definitions
 * 5. commission_records - Individual commission transactions
 * 6. commission_payouts - Monthly commission payroll
 * 7. reseller_accounts - White-label reseller partners
 * 8. reseller_customers - Customers managed by resellers
 * 9. reseller_billing - Monthly billing/invoices for resellers
 * 10. api_keys - API v2 authentication
 * 11. webhook_subscriptions - Webhook event subscriptions
 */

-- Table: geofences
-- Job site geofence boundaries for auto clock-in/out
CREATE TABLE IF NOT EXISTS geofences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  
  location_name VARCHAR(255) NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  radius_meters INTEGER NOT NULL DEFAULT 100,
  
  is_active BOOLEAN DEFAULT TRUE,
  activated_at TIMESTAMP WITH TIME ZONE,
  deactivated_at TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_geofences_project ON geofences(project_id);
CREATE INDEX IF NOT EXISTS idx_geofences_active ON geofences(is_active);

-- Table: location_tracking
-- GPS location history for accountability and geofence analysis
CREATE TABLE IF NOT EXISTS location_tracking (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  accuracy DECIMAL(8, 2), -- GPS accuracy in meters
  
  in_geofence BOOLEAN DEFAULT FALSE,
  geofence_id UUID REFERENCES geofences(id),
  
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_location_tracking_user ON location_tracking(user_id);
CREATE INDEX IF NOT EXISTS idx_location_tracking_task ON location_tracking(task_id);
CREATE INDEX IF NOT EXISTS idx_location_tracking_timestamp ON location_tracking(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_location_tracking_geofence ON location_tracking(geofence_id);

-- Table: geofence_alerts
-- User preferences for geofence event notifications
CREATE TABLE IF NOT EXISTS geofence_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  geofence_id UUID NOT NULL REFERENCES geofences(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  alert_type VARCHAR(20) CHECK (alert_type IN ('entry', 'exit', 'both')),
  is_enabled BOOLEAN DEFAULT TRUE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_geofence_alerts_geofence ON geofence_alerts(geofence_id);
CREATE INDEX IF NOT EXISTS idx_geofence_alerts_user ON geofence_alerts(user_id);

-- Table: commission_structures
-- Define commission calculation rules by company
CREATE TABLE IF NOT EXISTS commission_structures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL CHECK (type IN ('percentage', 'tiered', 'flat', 'hybrid')),
  
  base_rate DECIMAL(5, 2) NOT NULL,
  tiers JSONB DEFAULT '[]', -- [{minProfit, maxProfit, rate}, ...]
  bonus_threshold DECIMAL(5, 2),
  bonus_rate DECIMAL(5, 2),
  
  is_active BOOLEAN DEFAULT TRUE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_commission_structures_company ON commission_structures(company_id);

-- Table: commission_records
-- Individual commission transactions per salesperson/project
CREATE TABLE IF NOT EXISTS commission_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  salesperson_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  commission_structure_id UUID NOT NULL REFERENCES commission_structures(id),
  
  project_name VARCHAR(255),
  project_cost DECIMAL(12, 2) NOT NULL,
  project_revenue DECIMAL(12, 2) NOT NULL,
  profit_margin DECIMAL(12, 2) NOT NULL,
  
  commission_amount DECIMAL(12, 2) NOT NULL,
  commission_rate DECIMAL(5, 2) NOT NULL,
  
  status VARCHAR(20) CHECK (status IN ('pending', 'approved', 'paid')),
  approver_notes TEXT,
  
  approved_at TIMESTAMP WITH TIME ZONE,
  paid_at TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_commission_records_salesperson ON commission_records(salesperson_id);
CREATE INDEX IF NOT EXISTS idx_commission_records_project ON commission_records(project_id);
CREATE INDEX IF NOT EXISTS idx_commission_records_status ON commission_records(status);

-- Table: commission_payouts
-- Monthly commission payroll for salespeople
CREATE TABLE IF NOT EXISTS commission_payouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  salesperson_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  
  total_commission DECIMAL(12, 2) NOT NULL,
  project_count INTEGER NOT NULL DEFAULT 0,
  
  status VARCHAR(20) CHECK (status IN ('draft', 'approved', 'processed')),
  
  payout_date DATE,
  bank_account_number VARCHAR(255),
  bank_routing_number VARCHAR(255),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_commission_payouts_salesperson ON commission_payouts(salesperson_id);
CREATE INDEX IF NOT EXISTS idx_commission_payouts_status ON commission_payouts(status);

-- Table: reseller_accounts
-- White-label reseller partner accounts
CREATE TABLE IF NOT EXISTS reseller_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE SET NULL,
  
  company_name VARCHAR(255) NOT NULL,
  contact_email VARCHAR(255) NOT NULL,
  custom_domain VARCHAR(255) UNIQUE,
  
  branding_config JSONB NOT NULL DEFAULT '{}',
  
  billing_type VARCHAR(20) CHECK (billing_type IN ('revenue_share', 'per_user', 'tiered')),
  revenue_split_percent DECIMAL(5, 2),
  
  status VARCHAR(20) CHECK (status IN ('active', 'inactive', 'trial')),
  
  trial_ends_at TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_reseller_accounts_company ON reseller_accounts(company_id);
CREATE INDEX IF NOT EXISTS idx_reseller_accounts_custom_domain ON reseller_accounts(custom_domain);
CREATE INDEX IF NOT EXISTS idx_reseller_accounts_status ON reseller_accounts(status);

-- Table: reseller_customers
-- Customers managed by white-label resellers
CREATE TABLE IF NOT EXISTS reseller_customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reseller_id UUID NOT NULL REFERENCES reseller_accounts(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  
  customer_name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  
  onboarded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_reseller_customers_reseller ON reseller_customers(reseller_id);
CREATE INDEX IF NOT EXISTS idx_reseller_customers_project ON reseller_customers(project_id);

-- Table: reseller_billing
-- Monthly invoicing for reseller partners
CREATE TABLE IF NOT EXISTS reseller_billing (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reseller_id UUID NOT NULL REFERENCES reseller_accounts(id) ON DELETE CASCADE,
  
  billing_period_start DATE NOT NULL,
  billing_period_end DATE NOT NULL,
  
  charge_amount DECIMAL(12, 2) NOT NULL,
  revenue_split DECIMAL(12, 2),
  
  status VARCHAR(20) CHECK (status IN ('draft', 'invoiced', 'paid')),
  
  invoice_date TIMESTAMP WITH TIME ZONE,
  paid_date TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_reseller_billing_reseller ON reseller_billing(reseller_id);
CREATE INDEX IF NOT EXISTS idx_reseller_billing_status ON reseller_billing(status);

-- Table: api_keys
-- API v2 authentication keys for third-party integrations
CREATE TABLE IF NOT EXISTS api_keys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  key_hash VARCHAR(255) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  
  permissions TEXT[] DEFAULT '{}',
  rate_limit INTEGER DEFAULT 1000,
  
  is_active BOOLEAN DEFAULT TRUE,
  last_used_at TIMESTAMP WITH TIME ZONE,
  
  expires_at TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  revoked_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_api_keys_company ON api_keys(company_id);
CREATE INDEX IF NOT EXISTS idx_api_keys_active ON api_keys(is_active);

-- Table: webhook_subscriptions
-- Webhook event subscription management
CREATE TABLE IF NOT EXISTS webhook_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  
  event_type VARCHAR(255) NOT NULL,
  webhook_url VARCHAR(2048) NOT NULL,
  
  secret_token VARCHAR(255) NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  
  retry_count INTEGER DEFAULT 3,
  timeout_seconds INTEGER DEFAULT 30,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_webhook_subscriptions_company ON webhook_subscriptions(company_id);
CREATE INDEX IF NOT EXISTS idx_webhook_subscriptions_event ON webhook_subscriptions(event_type);

-- Row-Level Security Policies

ALTER TABLE geofences ENABLE ROW LEVEL SECURITY;
ALTER TABLE location_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE commission_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE commission_payouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE reseller_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_subscriptions ENABLE ROW LEVEL SECURITY;

-- Update timestamp triggers
CREATE OR REPLACE FUNCTION update_geofences_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER geofences_update_timestamp
  BEFORE UPDATE ON geofences
  FOR EACH ROW
  EXECUTE FUNCTION update_geofences_timestamp();

CREATE OR REPLACE FUNCTION update_commission_records_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER commission_records_update_timestamp
  BEFORE UPDATE ON commission_records
  FOR EACH ROW
  EXECUTE FUNCTION update_commission_records_timestamp();

CREATE OR REPLACE FUNCTION update_reseller_accounts_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER reseller_accounts_update_timestamp
  BEFORE UPDATE ON reseller_accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_reseller_accounts_timestamp();
