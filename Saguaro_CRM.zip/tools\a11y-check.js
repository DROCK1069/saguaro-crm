const fs = require('fs');
const path = require('path');
const jsdom = require('jsdom');
const { JSDOM } = jsdom;
const axe = require('axe-core');

async function runAxeOnFile(filePath) {
  const html = fs.readFileSync(filePath, 'utf8');
  const dom = new JSDOM(html, { runScripts: 'dangerously', resources: 'usable' });
  const { window } = dom;
  // inject axe source into the DOM
  const script = window.document.createElement('script');
  script.textContent = axe.source;
  window.document.head.appendChild(script);

  return new Promise((resolve) => {
    // Give any scripts a moment to run
    setTimeout(() => {
      try {
        window.axe.run(window.document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa'] } }, (err, results) => {
          if (err) return resolve({ file: filePath, error: String(err) });
          resolve({ file: filePath, results });
        });
      } catch (e) {
        resolve({ file: filePath, error: String(e) });
      }
    }, 250);
  });
}

async function main() {
  const base = path.resolve(__dirname, '..');
  const htmlFiles = [
    path.join(base, 'saguaro-preview.html')
  ];

  const outputs = [];
  for (const f of htmlFiles) {
    if (!fs.existsSync(f)) { outputs.push({ file: f, error: 'not found' }); continue; }
    // run
    process.stdout.write(`Running axe on ${path.basename(f)}... `);
    // eslint-disable-next-line no-await-in-loop
    const out = await runAxeOnFile(f);
    outputs.push(out);
    process.stdout.write('done\n');
  }

  // print summary
  for (const o of outputs) {
    console.log('-----');
    console.log('File:', o.file);
    if (o.error) { console.log('Error:', o.error); continue; }
    const v = o.results;
    console.log('Violations:', v.violations.length);
    v.violations.forEach((vi) => {
      console.log(`- ${vi.id} (${vi.impact}) — ${vi.help} — ${vi.nodes.length} node(s)`);
    });
  }
}

main().catch(e => { console.error(e); process.exit(2); });
