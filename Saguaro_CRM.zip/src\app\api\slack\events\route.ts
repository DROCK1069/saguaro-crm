import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/supabase/admin';
import { slackBot } from '@/lib/slackBot';
import crypto from 'crypto';

/**
 * Slack Events API endpoint
 * Handles slash commands, interactive actions, and event subscriptions
 * 
 * Slack -> POST to /api/slack/events
 * Verify request signature
 * Route to appropriate handler
 * Return 200 immediately (async processing)
 */

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const headers = Object.fromEntries(request.headers);

    // 1. Verify Slack request signature
    const timestamp = headers['x-slack-request-timestamp'];
    const signature = headers['x-slack-signature'];
    const signingSecret = process.env.SLACK_SIGNING_SECRET;

    if (!timestamp || !signature || !signingSecret) {
      console.error('Missing Slack verification headers');
      return NextResponse.json({ error: 'Missing headers' }, { status: 401 });
    }

    // Check timestamp is recent (within 5 minutes)
    const now = Math.floor(Date.now() / 1000);
    const requestTime = parseInt(timestamp);
    if (Math.abs(now - requestTime) > 300) {
      console.error('Request timestamp too old');
      return NextResponse.json({ error: 'Request too old' }, { status: 401 });
    }

    // Verify signature
    const baseString = `v0:${timestamp}:${body}`;
    const mySignature = 'v0=' + crypto
      .createHmac('sha256', signingSecret)
      .update(baseString)
      .digest('hex');

    if (crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(mySignature)) === false) {
      console.error('Invalid signature');
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
    }

    // 2. Parse payload
    const json = JSON.parse(body);

    // 3. Handle URL verification challenge
    if (json.type === 'url_verification') {
      return NextResponse.json({ challenge: json.challenge });
    }

    // 4. Handle Events
    if (json.type === 'event_callback') {
      const event = json.event;

      // Handle slash commands
      if (event.type === 'app_mention') {
        // Bot was mentioned - can add custom logic
        console.log('Bot mentioned:', event);
      }

      // Return 200 immediately, process async
      setImmediate(() => processSlackEvent(event));
      return NextResponse.json({ ok: true });
    }

    // 5. Handle Interactive Actions (button clicks)
    if (json.type === 'block_actions') {
      const action = json;

      setImmediate(() => processInteractiveAction(action));
      return NextResponse.json({ ok: true });
    }

    // 6. Handle View submissions (modal forms)
    if (json.type === 'view_submission') {
      const view = json.view;
      console.log('View submitted:', view);
      return NextResponse.json({ ok: true });
    }

    console.warn('Unknown Slack event type:', json.type);
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('Slack event processing error:', error);
    return NextResponse.json({ error: 'Processing failed' }, { status: 500 });
  }
}

/**
 * Process Slack events asynchronously
 */
async function processSlackEvent(event: any) {
  try {
    const db = supabaseAdmin;

    // Handle different event types
    if (event.type === 'app_mention') {
      // Parse mention text for commands
      const text = event.text.replace(/<@\w+>/g, '').trim();
      const userId = event.user;
      const channelId = event.channel;

      if (text.startsWith('/')) {
        const [command, ...args] = text.split(' ');
        // For now, skip complex command handling - just acknowledge
        const webhookUrl = process.env.SLACK_WEBHOOK_URL;
        if (webhookUrl) {
          // Command acknowledged
        }
      }
    }

    if (event.type === 'message' && !event.bot_id) {
      // Regular message - could trigger auto-processing
      console.log('Message received:', event.text);
    }
  } catch (error) {
    console.error('Event processing error:', error);
  }
}

/**
 * Process interactive actions (button clicks, select menus)
 */
async function processInteractiveAction(payload: any) {
  try {
    const db = supabaseAdmin;
    const action = payload.actions?.[0];
    const userId = payload.user.id;
    const responseUrl = payload.response_url;

    if (!action) return;

    // Route by action ID
    if (action.action_id === 'acknowledge_rfi') {
      const rfiId = action.value;
      const { error } = await db
        .from('rfis')
        .update({
          status: 'acknowledged',
          acknowledged_by: userId,
          acknowledged_at: new Date().toISOString(),
        })
        .eq('id', rfiId);

      if (!error && responseUrl) {
        await fetch(responseUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: `✅ RFI acknowledged by <@${userId}>`,
            replace_original: true,
          }),
        });
      }
    }

    if (action.action_id === 'resolve_rfi') {
      const rfiId = action.value;
      const { error } = await db
        .from('rfis')
        .update({
          status: 'resolved',
          resolved_by: userId,
          resolved_at: new Date().toISOString(),
        })
        .eq('id', rfiId);

      if (!error && responseUrl) {
        await fetch(responseUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: `✅ RFI resolved by <@${userId}>`,
            replace_original: true,
          }),
        });
      }
    }

    if (action.action_id === 'view_project') {
      const projectId = action.value;
      const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
      
      if (responseUrl) {
        await fetch(responseUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: `📍 Opening project: ${appUrl}/projects/${projectId}`,
            replace_original: false,
          }),
        });
      }
    }

    if (action.type === 'static_select') {
      // Handle dropdown selections
      const selectedValue = action.selected_option?.value;
      console.log('Selection made:', selectedValue);
    }
  } catch (error) {
    console.error('Interactive action processing error:', error);
  }
}
