import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/supabase/admin';
import { whiteLabelPortal } from '@/lib/whiteLabelPortal';

/**
 * White-Label Portal API
 * Manages reseller accounts, customer onboarding, and portal configuration
 * 
 * POST /api/resellers/accounts - Create reseller account
 * POST /api/resellers/domain - Set custom domain
 * POST /api/resellers/branding - Update branding
 * POST /api/resellers/customers - Onboard customer
 * GET /api/resellers/portal - Get portal configuration
 * GET /api/resellers/analytics - Get reseller analytics
 */

interface CreateResellerRequest {
  companyName: string;
  contactEmail: string;
  billingType: 'revenue_share' | 'per_user' | 'tiered';
  revenueSplitPercent?: number;
}

interface SetDomainRequest {
  resellerId: string;
  customDomain: string;
}

interface UpdateBrandingRequest {
  resellerId: string;
  branding: {
    logoUrl: string;
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    fontFamily: string;
    companyName: string;
    supportEmail: string;
    supportPhoneNumber?: string;
  };
}

interface OnboardCustomerRequest {
  resellerId: string;
  projectId: string;
  customerName: string;
  email: string;
  phone?: string;
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const url = new URL(request.url);
    const pathname = url.pathname;
    const db = supabaseAdmin;
    const body = await request.json();

    // Route: POST /api/resellers/accounts (create)
    if (pathname.includes('/accounts')) {
      const { companyName, contactEmail, billingType, revenueSplitPercent }: CreateResellerRequest = body;

      if (!companyName || !contactEmail || !billingType) {
        return NextResponse.json(
          { error: 'Missing required fields' },
          { status: 400 }
        );
      }

      const account = await whiteLabelPortal.createResellerAccount(
        companyName,
        contactEmail,
        billingType,
        revenueSplitPercent,
        undefined,
        db
      );

      return NextResponse.json(
        {
          success: true,
          data: account,
        },
        { status: 201 }
      );
    }

    // Route: POST /api/resellers/domain (set custom domain)
    if (pathname.includes('/domain')) {
      const { resellerId, customDomain }: SetDomainRequest = body;

      if (!resellerId || !customDomain) {
        return NextResponse.json(
          { error: 'Reseller ID and custom domain required' },
          { status: 400 }
        );
      }

      await whiteLabelPortal.setCustomDomain(resellerId, customDomain, db);

      return NextResponse.json(
        { success: true },
        { status: 200 }
      );
    }

    // Route: POST /api/resellers/branding (update branding)
    if (pathname.includes('/branding')) {
      const { resellerId, branding }: UpdateBrandingRequest = body;

      if (!resellerId || !branding) {
        return NextResponse.json(
          { error: 'Reseller ID and branding config required' },
          { status: 400 }
        );
      }

      await whiteLabelPortal.updateBranding(resellerId, branding, db);

      return NextResponse.json(
        { success: true },
        { status: 200 }
      );
    }

    // Route: POST /api/resellers/customers (onboard customer)
    if (pathname.includes('/customers')) {
      const { resellerId, projectId, customerName, email, phone }: OnboardCustomerRequest = body;

      if (!resellerId || !projectId || !customerName || !email) {
        return NextResponse.json(
          { error: 'Missing required fields' },
          { status: 400 }
        );
      }

      const customer = await whiteLabelPortal.onboardResellerCustomer(
        resellerId,
        projectId,
        customerName,
        email,
        phone,
        db
      );

      return NextResponse.json(
        {
          success: true,
          data: customer,
        },
        { status: 201 }
      );
    }

    // Route: POST /api/resellers/billing (generate monthly billing)
    if (pathname.includes('/billing')) {
      const { resellerId } = body;

      if (!resellerId) {
        return NextResponse.json(
          { error: 'Reseller ID required' },
          { status: 400 }
        );
      }

      const billing = await whiteLabelPortal.generateResellerBilling(resellerId, db);

      return NextResponse.json(
        {
          success: true,
          data: billing,
        },
        { status: 201 }
      );
    }

    return NextResponse.json(
      { error: 'Unknown endpoint' },
      { status: 404 }
    );
  } catch (error) {
    console.error('Reseller API error:', error);
    return NextResponse.json(
      { error: 'Request processing failed' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const { searchParams } = new URL(request.url);
    const resellerId = searchParams.get('resellerId');
    const url = new URL(request.url);
    const pathname = url.pathname;

    const db = supabaseAdmin;

    // Route: GET /api/resellers/portal?resellerId=...
    if (pathname.includes('/portal')) {
      if (!resellerId) {
        return NextResponse.json(
          { error: 'Reseller ID required' },
          { status: 400 }
        );
      }

      const portal = await whiteLabelPortal.getResellerPortal(resellerId, db);

      return NextResponse.json(
        {
          success: true,
          data: portal,
        },
        { status: 200 }
      );
    }

    // Route: GET /api/resellers/analytics?resellerId=...
    if (pathname.includes('/analytics')) {
      if (!resellerId) {
        return NextResponse.json(
          { error: 'Reseller ID required' },
          { status: 400 }
        );
      }

      const portal = await whiteLabelPortal.getResellerPortal(resellerId, db);

      return NextResponse.json(
        {
          success: true,
          data: {
            analytics: portal.analytics,
          },
        },
        { status: 200 }
      );
    }

    // Route: GET /api/resellers/template?resellerId=... (get HTML template)
    if (pathname.includes('/template')) {
      if (!resellerId) {
        return NextResponse.json(
          { error: 'Reseller ID required' },
          { status: 400 }
        );
      }

      const template = await whiteLabelPortal.getPortalTemplate(resellerId, db);

      return NextResponse.json(
        {
          success: true,
          html: template,
        },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { error: 'Unknown endpoint' },
      { status: 404 }
    );
  } catch (error) {
    console.error('Reseller GET error:', error);
    return NextResponse.json(
      { error: 'Request failed' },
      { status: 500 }
    );
  }
}
