import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/supabase/admin';
import { commissionEngine } from '@/lib/commissionEngine';

/**
 * Commission Tracking & Calculation API
 * Manages commission structures, calculations, and payouts
 * 
 * POST /api/commissions/calculate - Calculate commission for project
 * POST /api/commissions/structures - Create commission structure
 * POST /api/commissions/approve - Approve commission for payout
 * GET /api/commissions/record - Get commission record
 * GET /api/commissions/analytics - Get commission performance analytics
 */

interface CalculateCommissionRequest {
  salespersonId: string;
  projectId: string;
}

interface CommissionStructureRequest {
  name: string;
  type: 'percentage' | 'tiered' | 'flat' | 'hybrid';
  baseRate: number;
  tiers?: Array<{
    minProfit: number;
    maxProfit: number;
    rate: number;
  }>;
  bonusThreshold?: number;
  bonusRate?: number;
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const url = new URL(request.url);
    const pathname = url.pathname;
    const db = supabaseAdmin;
    const body = await request.json();

    // Route: POST /api/commissions/calculate
    if (pathname.includes('/calculate')) {
      const { salespersonId, projectId }: CalculateCommissionRequest = body;

      if (!salespersonId || !projectId) {
        return NextResponse.json(
          { error: 'Salesperson ID and Project ID required' },
          { status: 400 }
        );
      }

      const commission = await commissionEngine.calculateProjectCommission(
        salespersonId,
        projectId,
        db
      );

      return NextResponse.json(
        {
          success: true,
          data: commission,
        },
        { status: 201 }
      );
    }

    // Route: POST /api/commissions/structures (create)
    if (pathname.includes('/structures')) {
      const { name, type, baseRate, tiers, bonusThreshold, bonusRate }: CommissionStructureRequest = body;

      if (!name || !type || baseRate === undefined) {
        return NextResponse.json(
          { error: 'Missing required fields' },
          { status: 400 }
        );
      }

      // Get company ID from auth context
      const { data: { user } } = await supabaseAdmin.auth.getUser();
      if (!user?.id) {
        return NextResponse.json(
          { error: 'Unauthorized' },
          { status: 401 }
        );
      }

      const { data: userData } = await db
        .from('users')
        .select('company_id')
        .eq('id', user.id)
        .single();

      const structure = await commissionEngine.createCommissionStructure(
        db,
        name,
        type,
        baseRate,
        tiers,
        bonusThreshold,
        bonusRate
      );

      return NextResponse.json(
        {
          success: true,
          data: structure,
        },
        { status: 201 }
      );
    }

    // Route: POST /api/commissions/approve
    if (pathname.includes('/approve')) {
      const { commissionId, approverNotes } = body;

      if (!commissionId) {
        return NextResponse.json(
          { error: 'Commission ID required' },
          { status: 400 }
        );
      }

      await commissionEngine.approveCommission(commissionId, approverNotes, db);

      return NextResponse.json(
        { success: true },
        { status: 200 }
      );
    }

    // Route: POST /api/commissions/payout
    if (pathname.includes('/payout')) {
      const { commissionId, paymentDate } = body;

      if (!commissionId) {
        return NextResponse.json(
          { error: 'Commission ID required' },
          { status: 400 }
        );
      }

      await commissionEngine.markCommissionAsPaid(commissionId, paymentDate, db);

      return NextResponse.json(
        { success: true },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { error: 'Unknown endpoint' },
      { status: 404 }
    );
  } catch (error) {
    console.error('Commission API error: - route.ts:155', error);
    return NextResponse.json(
      { error: 'Request processing failed' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const { searchParams } = new URL(request.url);
    const salespersonId = searchParams.get('salespersonId');
    const commissionId = searchParams.get('commissionId');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const year = searchParams.get('year');
    const url = new URL(request.url);
    const pathname = url.pathname;

    const db = supabaseAdmin;

    // Route: GET /api/commissions/record?commissionId=...
    if (pathname.includes('/record')) {
      if (!commissionId) {
        return NextResponse.json(
          { error: 'Commission ID required' },
          { status: 400 }
        );
      }

      const { data, error } = await db
        .from('commission_records')
        .select('*')
        .eq('id', commissionId)
        .single();

      if (error || !data) {
        return NextResponse.json(
          { error: 'Commission not found' },
          { status: 404 }
        );
      }

      return NextResponse.json(
        {
          success: true,
          data,
        },
        { status: 200 }
      );
    }

    // Route: GET /api/commissions/history?salespersonId=...
    if (pathname.includes('/history')) {
      if (!salespersonId) {
        return NextResponse.json(
          { error: 'Salesperson ID required' },
          { status: 400 }
        );
      }

      const commissions = await commissionEngine.getSalespersonCommissions(
        salespersonId,
        startDate || undefined,
        endDate || undefined,
        db
      );

      return NextResponse.json(
        {
          success: true,
          data: commissions,
        },
        { status: 200 }
      );
    }

    // Route: GET /api/commissions/analytics?salespersonId=...&year=...
    if (pathname.includes('/analytics')) {
      if (!salespersonId || !year) {
        return NextResponse.json(
          { error: 'Salesperson ID and year required' },
          { status: 400 }
        );
      }

      const analytics = await commissionEngine.getCommissionAnalytics(
        salespersonId,
        parseInt(year),
        db
      );

      return NextResponse.json(
        {
          success: true,
          data: analytics,
        },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { error: 'Unknown endpoint' },
      { status: 404 }
    );
  } catch (error) {
    console.error('Commission GET error: - route.ts:261', error);
    return NextResponse.json(
      { error: 'Request failed' },
      { status: 500 }
    );
  }
}
