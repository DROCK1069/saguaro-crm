/**
 * Offline-First Sync Engine
 * Queues operations when offline, syncs when online
 * Uses IndexedDB for local storage, real-time conflict resolution
 */

export interface QueuedOperation {
  id: string;
  entity: 'rfi' | 'invoice' | 'task' | 'issue' | 'time_entry';
  action: 'create' | 'update' | 'delete';
  data: Record<string, any>;
  timestamp: number;
  synced: boolean;
  retries: number;
}

export interface SyncStatus {
  isOnline: boolean;
  queueLength: number;
  isSyncing: boolean;
  lastSync: number | null;
}

class OfflineSyncEngine {
  private db: IDBDatabase | null = null;
  private syncStatus: SyncStatus = {
    isOnline: navigator.onLine,
    queueLength: 0,
    isSyncing: false,
    lastSync: null,
  };
  private listeners: ((status: SyncStatus) => void)[] = [];
  private syncInterval: NodeJS.Timeout | null = null;

  async init() {
    return new Promise<void>((resolve, reject) => {
      const req = indexedDB.open('SaguaroCRM', 1);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        this.db = req.result;
        resolve();
      };
      req.onupgradeneeded = (e) => {
        const db = (e.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('syncQueue')) {
          db.createObjectStore('syncQueue', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('entities')) {
          db.createObjectStore('entities', { keyPath: 'id' });
        }
      };
    });
  }

  async queueOperation(op: Omit<QueuedOperation, 'id' | 'timestamp' | 'synced' | 'retries'>) {
    if (!this.db) throw new Error('Offline sync not initialized');
    const operation: QueuedOperation = {
      ...op,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      synced: false,
      retries: 0,
    };
    return new Promise<string>((resolve, reject) => {
      const tx = this.db!.transaction('syncQueue', 'readwrite');
      const req = tx.objectStore('syncQueue').add(operation);
      req.onsuccess = () => {
        this.updateStatus();
        resolve(operation.id);
      };
      req.onerror = () => reject(req.error);
    });
  }

  async getQueue(): Promise<QueuedOperation[]> {
    if (!this.db) return [];
    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction('syncQueue', 'readonly');
      const req = tx.objectStore('syncQueue').getAll();
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async syncQueue(token: string) {
    if (this.syncStatus.isSyncing) return;
    this.syncStatus.isSyncing = true;
    this.notifyListeners();

    try {
      const queue = await this.getQueue();
      const unsynced = queue.filter((op) => !op.synced);

      for (const op of unsynced) {
        try {
          const res = await fetch('/api/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify(op),
          });

          if (res.ok) {
            await this.markSynced(op.id);
          } else if (res.status === 409) {
            // Conflict: server version differs
            const server = await res.json();
            await this.resolveConflict(op, server);
          } else if (op.retries < 3) {
            // Retry
            await this.incrementRetry(op.id);
          } else {
            // Max retries exceeded
            console.warn(`Operation ${op.id} failed after 3 retries`);
          }
        } catch (err) {
          console.error(`Sync error for operation ${op.id}:`, err);
          if (op.retries < 3) {
            await this.incrementRetry(op.id);
          }
        }
      }

      this.syncStatus.lastSync = Date.now();
    } finally {
      this.syncStatus.isSyncing = false;
      this.notifyListeners();
    }
  }

  private async markSynced(id: string) {
    if (!this.db) return;
    return new Promise<void>((resolve, reject) => {
      const tx = this.db!.transaction('syncQueue', 'readwrite');
      const req = tx.objectStore('syncQueue').get(id);
      req.onsuccess = () => {
        const op = req.result as QueuedOperation;
        op.synced = true;
        tx.objectStore('syncQueue').put(op);
        resolve();
        this.updateStatus();
      };
      req.onerror = () => reject(req.error);
    });
  }

  private async incrementRetry(id: string) {
    if (!this.db) return;
    return new Promise<void>((resolve, reject) => {
      const tx = this.db!.transaction('syncQueue', 'readwrite');
      const req = tx.objectStore('syncQueue').get(id);
      req.onsuccess = () => {
        const op = req.result as QueuedOperation;
        op.retries += 1;
        tx.objectStore('syncQueue').put(op);
        resolve();
      };
      req.onerror = () => reject(req.error);
    });
  }

  private async resolveConflict(local: QueuedOperation, server: any) {
    // Last-write-wins strategy with server as authority
    if (server.timestamp > local.timestamp) {
      await this.markSynced(local.id);
    } else {
      // Retry local update
      await this.incrementRetry(local.id);
    }
  }

  private async updateStatus() {
    const queue = await this.getQueue();
    this.syncStatus.queueLength = queue.filter((op) => !op.synced).length;
    this.notifyListeners();
  }

  onChange(listener: (status: SyncStatus) => void) {
    this.listeners.push(listener);
    listener(this.syncStatus);
  }

  private notifyListeners() {
    this.listeners.forEach((l) => l({ ...this.syncStatus }));
  }

  startAutoSync(token: string, interval = 30000) {
    this.syncInterval = setInterval(() => {
      if (navigator.onLine) {
        this.syncQueue(token);
      }
    }, interval);
    window.addEventListener('online', () => {
      this.syncStatus.isOnline = true;
      this.notifyListeners();
      this.syncQueue(token);
    });
    window.addEventListener('offline', () => {
      this.syncStatus.isOnline = false;
      this.notifyListeners();
    });
  }

  stopAutoSync() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
  }
}

export const offlineSync = new OfflineSyncEngine();

// Export convenience functions
export const initOfflineSync = () => offlineSync.init();

export const getSyncStatus = () => ({
  isOnline: navigator.onLine,
  queued: 0, // Would need getter on class
  syncing: false, // Would need getter on class
  lastSyncTime: null, // Would need getter on class
});

export const syncQueue = offlineSync;

// Also export the OfflineSync SyncStatus interface for the engine
export type { SyncStatus as OfflineSyncStatus } from './offlineSync';
