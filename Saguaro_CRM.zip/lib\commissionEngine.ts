/**
 * Commission Tracking & Calculation Engine
 * Tracks salesperson commissions based on project profitability
 * Handles multiple commission structures (percentage, tiered, flat)
 * 
 * Features:
 * - Track commission-eligible projects
 * - Calculate commissions based on profit margin
 * - Support tiered commission structures
 * - Generate commission reports
 * - Handle payouts
 */

export type CommissionType = 'percentage' | 'tiered' | 'flat' | 'hybrid';

export interface CommissionStructure {
  id: string;
  name: string;
  type: CommissionType;
  baseRate: number;
  tiers?: Array<{
    minProfit: number;
    maxProfit: number;
    rate: number;
  }>;
  bonusThreshold?: number;
  bonusRate?: number;
  isActive: boolean;
  createdAt: string;
}

export interface CommissionRecord {
  id: string;
  salespersonId: string;
  projectId: string;
  projectName: string;
  commissionStructureId: string;
  projectCost: number;
  projectRevenue: number;
  profitMargin: number;
  commissionAmount: number;
  commissionRate: number;
  status: 'pending' | 'approved' | 'paid';
  paidAt?: string;
  createdAt: string;
  approvedAt?: string;
}

export interface CommissionPayout {
  id: string;
  salespersonId: string;
  periodStart: string;
  periodEnd: string;
  totalCommission: number;
  projectCount: number;
  payoutDate?: string;
  status: 'draft' | 'approved' | 'processed';
  bankDetails?: {
    accountNumber: string;
    routingNumber: string;
  };
}

class CommissionEngine {
  /**
   * Create a commission structure
   */
  async createCommissionStructure(
    db: any,
    name: string,
    type: CommissionType,
    baseRate: number,
    tiers?: any[],
    bonusThreshold?: number,
    bonusRate?: number
  ): Promise<CommissionStructure> {
    const { data, error } = await db
      .from('commission_structures')
      .insert([
        {
          name,
          type,
          base_rate: baseRate,
          tiers: tiers || null,
          bonus_threshold: bonusThreshold,
          bonus_rate: bonusRate,
          is_active: true,
          created_at: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      name: data.name,
      type: data.type,
      baseRate: data.base_rate,
      tiers: data.tiers,
      bonusThreshold: data.bonus_threshold,
      bonusRate: data.bonus_rate,
      isActive: data.is_active,
      createdAt: data.created_at,
    };
  }

  /**
   * Calculate commission for a completed project
   */
  async calculateProjectCommission(
    salespersonId: string,
    projectId: string,
    db: any
  ): Promise<CommissionRecord> {
    // Get project details
    const { data: project, error: projError } = await db
      .from('projects')
      .select('name, budget, actual_cost')
      .eq('id', projectId)
      .single();

    if (projError || !project) {
      throw new Error('Project not found');
    }

    // Get salesperson commission structure
    const { data: salesperson, error: salesError } = await db
      .from('users')
      .select('commission_structure_id, company_id')
      .eq('id', salespersonId)
      .single();

    if (salesError || !salesperson) {
      throw new Error('Salesperson not found');
    }

    // Get commission structure
    const { data: structure, error: structError } = await db
      .from('commission_structures')
      .select('*')
      .eq('id', salesperson.commission_structure_id)
      .single();

    if (structError || !structure) {
      throw new Error('Commission structure not found');
    }

    // Calculate commission
    const projectRevenue = project.budget;
    const projectCost = project.actual_cost || 0;
    const profitMargin = projectRevenue - projectCost;
    const profitMarginPercent = (profitMargin / projectRevenue) * 100;

    let commissionRate = structure.base_rate;
    let commissionAmount = 0;

    // Apply tiered rates if applicable
    if (structure.type === 'tiered' && structure.tiers) {
      for (const tier of structure.tiers) {
        if (profitMargin >= tier.min_profit && profitMargin <= tier.max_profit) {
          commissionRate = tier.rate;
          break;
        }
      }
    }

    // Calculate base commission
    commissionAmount = projectRevenue * (commissionRate / 100);

    // Apply bonus if applicable
    if (structure.bonus_threshold && profitMarginPercent > structure.bonus_threshold) {
      const bonusAmount = (projectRevenue * (structure.bonus_rate || 0)) / 100;
      commissionAmount += bonusAmount;
    }

    // Record commission
    const { data: record, error: recordError } = await db
      .from('commission_records')
      .insert([
        {
          salesperson_id: salespersonId,
          project_id: projectId,
          commission_structure_id: salesperson.commission_structure_id,
          project_cost: projectCost,
          project_revenue: projectRevenue,
          profit_margin: profitMargin,
          commission_amount: commissionAmount,
          commission_rate: commissionRate,
          status: 'pending',
          created_at: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (recordError) throw recordError;

    return {
      id: record.id,
      salespersonId: record.salesperson_id,
      projectId: record.project_id,
      projectName: project.name,
      commissionStructureId: record.commission_structure_id,
      projectCost: record.project_cost,
      projectRevenue: record.project_revenue,
      profitMargin: record.profit_margin,
      commissionAmount: record.commission_amount,
      commissionRate: record.commission_rate,
      status: record.status,
      createdAt: record.created_at,
    };
  }

  /**
   * Generate commission payroll for a period
   */
  async generateCommissionPayroll(
    salespersonId: string,
    periodStart: string,
    periodEnd: string,
    db: any
  ): Promise<CommissionPayout> {
    const startDate = new Date(periodStart);
    const endDate = new Date(periodEnd);

    // Get all approved commissions in period
    const { data: records, error } = await db
      .from('commission_records')
      .select('*')
      .eq('salesperson_id', salespersonId)
      .eq('status', 'approved')
      .gte('created_at', startDate.toISOString())
      .lte('created_at', endDate.toISOString());

    if (error) throw error;

    const totalCommission = records.reduce((sum: number, r: any) => sum + r.commission_amount, 0);

    // Create payout record
    const { data: payout, error: payoutError } = await db
      .from('commission_payouts')
      .insert([
        {
          salesperson_id: salespersonId,
          period_start: startDate.toISOString(),
          period_end: endDate.toISOString(),
          total_commission: totalCommission,
          project_count: records.length,
          status: 'draft',
          created_at: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (payoutError) throw payoutError;

    return {
      id: payout.id,
      salespersonId: payout.salesperson_id,
      periodStart: payout.period_start,
      periodEnd: payout.period_end,
      totalCommission: payout.total_commission,
      projectCount: payout.project_count,
      status: payout.status,
    };
  }

  /**
   * Get salesperson commission history
   */
  async getSalespersonCommissions(
    salespersonId: string,
    startDate?: string,
    endDate?: string,
    db?: any
  ): Promise<CommissionRecord[]> {
    let query = db.from('commission_records').select('*').eq('salesperson_id', salespersonId);

    if (startDate) {
      query = query.gte('created_at', startDate);
    }

    if (endDate) {
      query = query.lte('created_at', endDate);
    }

    const { data, error } = await query.order('created_at', { ascending: false });

    if (error) throw error;

    return (data || []).map((r: any) => ({
      id: r.id,
      salespersonId: r.salesperson_id,
      projectId: r.project_id,
      projectName: r.project_name,
      commissionStructureId: r.commission_structure_id,
      projectCost: r.project_cost,
      projectRevenue: r.project_revenue,
      profitMargin: r.profit_margin,
      commissionAmount: r.commission_amount,
      commissionRate: r.commission_rate,
      status: r.status,
      createdAt: r.created_at,
      approvedAt: r.approved_at,
      paidAt: r.paid_at,
    }));
  }

  /**
   * Approve commission for payout
   */
  async approveCommission(commissionId: string, approverNotes?: string, db?: any): Promise<void> {
    const { error } = await db
      .from('commission_records')
      .update({
        status: 'approved',
        approved_at: new Date().toISOString(),
        approver_notes: approverNotes,
      })
      .eq('id', commissionId);

    if (error) throw error;
  }

  /**
   * Mark commission as paid
   */
  async markCommissionAsPaid(commissionId: string, paymentDate?: string, db?: any): Promise<void> {
    const { error } = await db
      .from('commission_records')
      .update({
        status: 'paid',
        paid_at: paymentDate || new Date().toISOString(),
      })
      .eq('id', commissionId);

    if (error) throw error;
  }

  /**
   * Generate commission performance analytics
   */
  async getCommissionAnalytics(
    salespersonId: string,
    year: number,
    db: any
  ): Promise<{
    totalEarned: number;
    avgCommissionPerProject: number;
    topProject: { projectName: string; amount: number };
    monthlyBreakdown: Array<{ month: string; amount: number }>;
    projectionForYear: number;
  }> {
    const startOfYear = new Date(`${year}-01-01`).toISOString();
    const endOfYear = new Date(`${year}-12-31`).toISOString();

    const { data: records } = await db
      .from('commission_records')
      .select('*')
      .eq('salesperson_id', salespersonId)
      .eq('status', 'approved')
      .gte('created_at', startOfYear)
      .lte('created_at', endOfYear);

    const totalEarned = records.reduce((sum: number, r: any) => sum + r.commission_amount, 0);
    const avgCommissionPerProject = records.length > 0 ? totalEarned / records.length : 0;
    const topProject = records.reduce(
      (max: any, r: any) => (r.commission_amount > (max.commission_amount || 0) ? r : max),
      {}
    );

    // Monthly breakdown
    const monthlyBreakdown = Array.from({ length: 12 }).map((_, i) => ({
      month: new Date(year, i, 1).toLocaleDateString('en-US', { month: 'long' }),
      amount: records
        .filter((r: any) => new Date(r.created_at).getMonth() === i)
        .reduce((sum: number, r: any) => sum + r.commission_amount, 0),
    }));

    // Projection for full year
    const daysPassed = Math.ceil((Date.now() - new Date(`${year}-01-01`).getTime()) / (1000 * 60 * 60 * 24));
    const projectionForYear = (totalEarned / daysPassed) * 365;

    return {
      totalEarned,
      avgCommissionPerProject,
      topProject: {
        projectName: topProject.project_name || 'N/A',
        amount: topProject.commission_amount || 0,
      },
      monthlyBreakdown,
      projectionForYear,
    };
  }
}

export const commissionEngine = new CommissionEngine();
