/**
 * Report Builder UI Component
 * Interactive interface for creating and running custom reports
 */

'use client';

import React, { useState } from 'react';
import { generateReport, exportToCSV, exportToPDF } from '@/lib/reportBuilder';

interface FilterRule {
  field: string;
  operator: 'eq' | 'gt' | 'lt' | 'gte' | 'lte' | 'ilike' | 'between';
  value: string | number;
}

export default function ReportBuilder() {
  const [entity, setEntity] = useState<'invoices' | 'rfis' | 'tasks' | 'projects'>('invoices');
  const [name, setName] = useState('');
  const [filters, setFilters] = useState<FilterRule[]>([]);
  const [sortBy, setSortBy] = useState('created_at:desc');
  const [groupBy, setGroupBy] = useState('');
  const [selectedFields, setSelectedFields] = useState<string[]>(['id', 'created_at']);
  const [reportData, setReportData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fieldsByEntity = {
    invoices: ['id', 'invoice_number', 'total', 'status', 'due_date', 'created_at', 'client_name'],
    rfis: ['id', 'rfi_number', 'status', 'due_date', 'created_at', 'days_overdue'],
    tasks: ['id', 'title', 'status', 'assigned_to', 'planned_start', 'planned_finish', 'actual_finish'],
    projects: ['id', 'name', 'status', 'value', 'start_date', 'end_date', 'progress_percent'],
  };

  const handleAddFilter = () => {
    setFilters([...filters, { field: 'status', operator: 'eq', value: '' }]);
  };

  const handleUpdateFilter = (index: number, field: keyof FilterRule, value: any) => {
    const updated = [...filters];
    updated[index] = { ...updated[index], [field]: value };
    setFilters(updated);
  };

  const handleRemoveFilter = (index: number) => {
    setFilters(filters.filter((_, i) => i !== index));
  };

  const toggleField = (field: string) => {
    setSelectedFields(prev =>
      prev.includes(field)
        ? prev.filter(f => f !== field)
        : [...prev, field]
    );
  };

  const handleGenerateReport = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await generateReport(
        entity,
        selectedFields,
        filters as any,
        sortBy,
        groupBy || undefined
      );
      setReportData(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate report');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (format: 'csv' | 'pdf') => {
    if (!reportData) return;

    setLoading(true);
    try {
      if (format === 'csv') {
        const csv = await exportToCSV(reportData, selectedFields, name);
        downloadFile(csv, `${name || 'report'}.csv`, 'text/csv');
      } else {
        const html = await exportToPDF(reportData, selectedFields, name);
        downloadFile(html, `${name || 'report'}.html`, 'text/html');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Export failed');
    } finally {
      setLoading(false);
    }
  };

  const downloadFile = (content: string, filename: string, mimeType: string) => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      <h2 style={{ marginBottom: '20px' }}>Custom Report Builder</h2>

      {error && (
        <div
          style={{
            padding: '12px',
            backgroundColor: '#fee2e2',
            color: '#991b1b',
            borderRadius: '4px',
            marginBottom: '16px',
          }}
        >
          {error}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px', marginBottom: '20px' }}>
        {/* Entity Select */}
        <div>
          <label style={{ display: 'block', marginBottom: '4px', fontWeight: '500' }}>
            Data Source
          </label>
          <select
            value={entity}
            onChange={e => setEntity(e.target.value as any)}
            style={{
              width: '100%',
              padding: '8px',
              border: '1px solid #e5e7eb',
              borderRadius: '4px',
            }}
          >
            <option value="invoices">Invoices</option>
            <option value="rfis">RFIs</option>
            <option value="tasks">Tasks</option>
            <option value="projects">Projects</option>
          </select>
        </div>

        {/* Report Name */}
        <div>
          <label style={{ display: 'block', marginBottom: '4px', fontWeight: '500' }}>
            Report Name
          </label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="e.g., Q4 Invoice Report"
            style={{
              width: '100%',
              padding: '8px',
              border: '1px solid #e5e7eb',
              borderRadius: '4px',
              boxSizing: 'border-box',
            }}
          />
        </div>

        {/* Sort By */}
        <div>
          <label style={{ display: 'block', marginBottom: '4px', fontWeight: '500' }}>
            Sort By
          </label>
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value)}
            style={{
              width: '100%',
              padding: '8px',
              border: '1px solid #e5e7eb',
              borderRadius: '4px',
            }}
          >
            <option value="created_at:desc">Newest First</option>
            <option value="created_at:asc">Oldest First</option>
            <option value="total:desc">Total (High to Low)</option>
            <option value="total:asc">Total (Low to High)</option>
          </select>
        </div>
      </div>

      {/* Field Selection */}
      <div style={{ marginBottom: '20px' }}>
        <h3 style={{ marginBottom: '12px' }}>Fields to Include</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
          {fieldsByEntity[entity].map(field => (
            <label key={field} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <input
                type="checkbox"
                checked={selectedFields.includes(field)}
                onChange={() => toggleField(field)}
              />
              {field}
            </label>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div style={{ marginBottom: '20px', padding: '16px', backgroundColor: '#f9fafb', borderRadius: '4px' }}>
        <h3 style={{ marginBottom: '12px' }}>Filters</h3>
        {filters.length === 0 ? (
          <p style={{ color: '#6b7280', marginBottom: '12px' }}>No filters applied</p>
        ) : (
          <div style={{ marginBottom: '12px' }}>
            {filters.map((filter, index) => (
              <div key={index} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 50px', gap: '8px', marginBottom: '8px' }}>
                <select
                  value={filter.field}
                  onChange={e => handleUpdateFilter(index, 'field', e.target.value)}
                  style={{ padding: '6px', border: '1px solid #d1d5db', borderRadius: '4px' }}
                >
                  {fieldsByEntity[entity].map(f => (
                    <option key={f} value={f}>{f}</option>
                  ))}
                </select>

                <select
                  value={filter.operator}
                  onChange={e => handleUpdateFilter(index, 'operator', e.target.value)}
                  style={{ padding: '6px', border: '1px solid #d1d5db', borderRadius: '4px' }}
                >
                  <option value="eq">equals</option>
                  <option value="gt">greater than</option>
                  <option value="lt">less than</option>
                  <option value="gte">≥</option>
                  <option value="lte">≤</option>
                  <option value="ilike">contains</option>
                  <option value="between">between</option>
                </select>

                <input
                  type="text"
                  value={filter.value}
                  onChange={e => handleUpdateFilter(index, 'value', e.target.value)}
                  placeholder="value"
                  style={{ padding: '6px', border: '1px solid #d1d5db', borderRadius: '4px' }}
                />

                <button
                  onClick={() => handleRemoveFilter(index)}
                  style={{
                    padding: '6px 12px',
                    backgroundColor: '#ef4444',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                  }}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        )}
        <button
          onClick={handleAddFilter}
          style={{
            padding: '8px 12px',
            backgroundColor: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          + Add Filter
        </button>
      </div>

      {/* Action Buttons */}
      <div style={{ display: 'flex', gap: '12px', marginBottom: '20px' }}>
        <button
          onClick={handleGenerateReport}
          disabled={loading || selectedFields.length === 0}
          style={{
            padding: '10px 20px',
            backgroundColor: '#10b981',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: loading ? 'not-allowed' : 'pointer',
            opacity: loading ? 0.6 : 1,
          }}
        >
          {loading ? 'Generating...' : 'Generate Report'}
        </button>

        {reportData && (
          <>
            <button
              onClick={() => handleExport('csv')}
              disabled={loading}
              style={{
                padding: '10px 20px',
                backgroundColor: '#8b5cf6',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: loading ? 'not-allowed' : 'pointer',
              }}
            >
              Export CSV
            </button>
            <button
              onClick={() => handleExport('pdf')}
              disabled={loading}
              style={{
                padding: '10px 20px',
                backgroundColor: '#ec4899',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: loading ? 'not-allowed' : 'pointer',
              }}
            >
              Export PDF
            </button>
          </>
        )}
      </div>

      {/* Results Table */}
      {reportData && (
        <div style={{ overflowX: 'auto' }}>
          <h3 style={{ marginBottom: '12px' }}>Results ({reportData.length} rows)</h3>
          <table
            style={{
              width: '100%',
              borderCollapse: 'collapse',
              backgroundColor: 'white',
              borderRadius: '4px',
              overflow: 'hidden',
            }}
          >
            <thead>
              <tr style={{ backgroundColor: '#f3f4f6', borderBottom: '1px solid #e5e7eb' }}>
                {selectedFields.map(field => (
                  <th
                    key={field}
                    style={{
                      padding: '12px',
                      textAlign: 'left',
                      fontWeight: '600',
                      fontSize: '14px',
                    }}
                  >
                    {field}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {reportData.slice(0, 50).map((row: any, index: number) => (
                <tr key={index} style={{ borderBottom: '1px solid #e5e7eb' }}>
                  {selectedFields.map(field => (
                    <td
                      key={`${index}-${field}`}
                      style={{
                        padding: '12px',
                        fontSize: '14px',
                        color: '#374151',
                      }}
                    >
                      {formatCellValue(row[field])}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
          {reportData.length > 50 && (
            <p style={{ marginTop: '12px', color: '#6b7280' }}>
              Showing 50 of {reportData.length} results (export to see all)
            </p>
          )}
        </div>
      )}
    </div>
  );
}

function formatCellValue(value: any): string {
  if (value === null || value === undefined) return '-';
  if (typeof value === 'boolean') return value ? 'Yes' : 'No';
  if (typeof value === 'number') {
    if (value > 1000) return '$' + value.toLocaleString('en-US', { maximumFractionDigits: 2 });
    return value.toString();
  }
  if (value instanceof Date) return value.toLocaleDateString();
  return String(value);
}
