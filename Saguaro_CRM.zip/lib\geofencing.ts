/**
 * Geofencing & Location Tracking Service
 * Handles location-based time tracking, auto clock-in/out at job sites
 * Uses Haversine formula for distance calculations
 * 
 * Features:
 * - Geofence creation around job sites
 * - Automatic clock-in when entering geofence
 * - Automatic clock-out when leaving geofence
 * - Location tracking for accountability
 * - Overtime detection in geofenced zones
 */

export interface Geofence {
  id: string;
  projectId: string;
  locationName: string;
  latitude: number;
  longitude: number;
  radiusMeters: number;
  createdAt: string;
  activatedAt?: string;
  deactivatedAt?: string;
  isActive: boolean;
}

export interface LocationEntry {
  id: string;
  userId: string;
  taskId: string;
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: string;
  inGeofence: boolean;
  geofenceId?: string;
}

export interface GeofenceEvent {
  type: 'enter' | 'exit';
  userId: string;
  geofenceId: string;
  taskId: string;
  timestamp: string;
  latitude: number;
  longitude: number;
  actionTaken?: 'auto_clock_in' | 'auto_clock_out' | 'notify';
}

class GeofencingService {
  /**
   * Create a geofence around a job site
   */
  async createGeofence(
    projectId: string,
    locationName: string,
    latitude: number,
    longitude: number,
    radiusMeters: number = 100,
    db: any
  ): Promise<Geofence> {
    const { data, error } = await db
      .from('geofences')
      .insert([
        {
          project_id: projectId,
          location_name: locationName,
          latitude,
          longitude,
          radius_meters: radiusMeters,
          is_active: true,
          created_at: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      projectId: data.project_id,
      locationName: data.location_name,
      latitude: data.latitude,
      longitude: data.longitude,
      radiusMeters: data.radius_meters,
      createdAt: data.created_at,
      isActive: data.is_active,
    };
  }

  /**
   * Track user location and detect geofence events
   */
  async trackLocation(
    userId: string,
    taskId: string,
    latitude: number,
    longitude: number,
    accuracy: number,
    db: any
  ): Promise<GeofenceEvent | null> {
    const timestamp = new Date().toISOString();

    // Record location entry
    const { error: locError } = await db.from('location_tracking').insert([
      {
        user_id: userId,
        task_id: taskId,
        latitude,
        longitude,
        accuracy,
        timestamp,
      },
    ]);

    if (locError) console.error('Location tracking error:', locError);

    // Get active geofences for this task's project
    const { data: task } = await db
      .from('tasks')
      .select('project_id')
      .eq('id', taskId)
      .single();

    if (!task) return null;

    const { data: geofences } = await db
      .from('geofences')
      .select('*')
      .eq('project_id', task.project_id)
      .eq('is_active', true);

    if (!geofences || geofences.length === 0) return null;

    // Check if user entered or exited any geofence
    for (const geofence of geofences) {
      const distance = this.calculateDistance(
        latitude,
        longitude,
        geofence.latitude,
        geofence.longitude
      );

      const isInGeofence = distance <= geofence.radius_meters;

      // Check previous location to detect enter/exit
      const { data: lastLocation } = await db
        .from('location_tracking')
        .select('*')
        .eq('user_id', userId)
        .eq('task_id', taskId)
        .order('timestamp', { ascending: false })
        .limit(2);

      if (lastLocation && lastLocation.length > 1) {
        const prevLocation = lastLocation[1];
        const prevDistance = this.calculateDistance(
          prevLocation.latitude,
          prevLocation.longitude,
          geofence.latitude,
          geofence.longitude
        );

        const wasInGeofence = prevDistance <= geofence.radius_meters;

        // Detect geofence entry
        if (!wasInGeofence && isInGeofence) {
          const event: GeofenceEvent = {
            type: 'enter',
            userId,
            geofenceId: geofence.id,
            taskId,
            timestamp,
            latitude,
            longitude,
          };

          // Auto clock-in
          const clockedIn = await this.autoClockIn(userId, taskId, geofence.location_name, db);
          if (clockedIn) {
            event.actionTaken = 'auto_clock_in';
          }

          return event;
        }

        // Detect geofence exit
        if (wasInGeofence && !isInGeofence) {
          const event: GeofenceEvent = {
            type: 'exit',
            userId,
            geofenceId: geofence.id,
            taskId,
            timestamp,
            latitude,
            longitude,
          };

          // Auto clock-out
          const clockedOut = await this.autoClockOut(userId, taskId, db);
          if (clockedOut) {
            event.actionTaken = 'auto_clock_out';
          }

          return event;
        }
      }
    }

    return null;
  }

  /**
   * Automatically clock in user at geofence entry
   */
  private async autoClockIn(userId: string, taskId: string, locationName: string, db: any): Promise<boolean> {
    try {
      // Check if already clocked in for this task
      const { data: existing } = await db
        .from('time_entries')
        .select('id')
        .eq('user_id', userId)
        .eq('task_id', taskId)
        .is('end_time', null)
        .limit(1);

      if (existing && existing.length > 0) {
        return false; // Already clocked in
      }

      // Create new time entry
      const { error } = await db.from('time_entries').insert([
        {
          user_id: userId,
          task_id: taskId,
          start_time: new Date().toISOString(),
          geofence_auto_clockin: true,
          location_name: locationName,
        },
      ]);

      return !error;
    } catch (err) {
      console.error('Auto clock-in error:', err);
      return false;
    }
  }

  /**
   * Automatically clock out user at geofence exit
   */
  private async autoClockOut(userId: string, taskId: string, db: any): Promise<boolean> {
    try {
      const { error } = await db
        .from('time_entries')
        .update({
          end_time: new Date().toISOString(),
          geofence_auto_clockout: true,
        })
        .eq('user_id', userId)
        .eq('task_id', taskId)
        .is('end_time', null);

      return !error;
    } catch (err) {
      console.error('Auto clock-out error:', err);
      return false;
    }
  }

  /**
   * Haversine formula to calculate distance between two coordinates
   * Returns distance in meters
   */
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371000; // Earth's radius in meters
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) *
      Math.sin(Δλ / 2) * Math.sin(Δλ / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  }

  /**
   * Set up geofence alert notifications
   */
  async setupGeofenceAlert(geofenceId: string, userId: string, alertType: 'entry' | 'exit', db: any): Promise<void> {
    await db.from('geofence_alerts').insert([
      {
        geofence_id: geofenceId,
        user_id: userId,
        alert_type: alertType,
        is_enabled: true,
        created_at: new Date().toISOString(),
      },
    ]);
  }

  /**
   * Get all geofences for a project
   */
  async getProjectGeofences(projectId: string, db: any): Promise<Geofence[]> {
    const { data, error } = await db
      .from('geofences')
      .select('*')
      .eq('project_id', projectId)
      .eq('is_active', true);

    if (error) throw error;

    return data.map((g: any) => ({
      id: g.id,
      projectId: g.project_id,
      locationName: g.location_name,
      latitude: g.latitude,
      longitude: g.longitude,
      radiusMeters: g.radius_meters,
      createdAt: g.created_at,
      isActive: g.is_active,
    }));
  }

  /**
   * Generate geofence summary for reporting
   */
  async generateGeofenceSummary(projectId: string, userId: string, db: any): Promise<{
    totalTimeInGeofence: number;
    geofenceVisits: number;
    tasksClockedViaGeofence: number;
    averageSessionDuration: number;
  }> {
    const { data: geofences } = await db
      .from('geofences')
      .select('id')
      .eq('project_id', projectId);

    if (!geofences) {
      return {
        totalTimeInGeofence: 0,
        geofenceVisits: 0,
        tasksClockedViaGeofence: 0,
        averageSessionDuration: 0,
      };
    }

    const geofenceIds = geofences.map((g: any) => g.id);

    // Get time entries auto-clocked via geofence
    const { data: entries } = await db
      .from('time_entries')
      .select('*')
      .eq('user_id', userId)
      .eq('geofence_auto_clockin', true)
      .in('geofence_id', geofenceIds);

    let totalMinutes = 0;
    let count = 0;

    if (entries) {
      entries.forEach((entry: any) => {
        if (entry.start_time && entry.end_time) {
          const duration = new Date(entry.end_time).getTime() - new Date(entry.start_time).getTime();
          totalMinutes += duration / (1000 * 60);
          count++;
        }
      });
    }

    return {
      totalTimeInGeofence: totalMinutes,
      geofenceVisits: count,
      tasksClockedViaGeofence: count,
      averageSessionDuration: count > 0 ? totalMinutes / count : 0,
    };
  }
}

export const geofencing = new GeofencingService();
