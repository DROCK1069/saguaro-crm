/**
 * White-Label Portal Engine
 * Enables reseller partners to manage their own branded customer portals
 * Featured: Multi-tenant architecture, custom branding, white-label pricing
 * 
 * Features:
 * - Reseller account management
 * - Custom domain & branding per reseller
 * - Customer portal with reseller branding
 * - Revenue sharing & billing
 * - Usage tracking & analytics
 */

export interface ResellerAccount {
  id: string;
  companyName: string;
  contactEmail: string;
  customDomain?: string;
  brandingConfig: BrandingConfig;
  billingType: 'revenue_share' | 'per_user' | 'tiered';
  revenueSplitPercent?: number;
  status: 'active' | 'inactive' | 'trial';
  createdAt: string;
  trialEndsAt?: string;
}

export interface BrandingConfig {
  logoUrl: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontFamily: string;
  companyName: string;
  supportEmail: string;
  supportPhoneNumber?: string;
  websiteUrl?: string;
  customCss?: string;
}

export interface ResellerCustomer {
  id: string;
  resellerId: string;
  projectId: string;
  customerName: string;
  email: string;
  phone?: string;
  onboardedAt: string;
}

export interface ResellerBilling {
  id: string;
  resellerId: string;
  billingPeriodStart: string;
  billingPeriodEnd: string;
  chargeAmount: number;
  revenueSplit?: number;
  status: 'draft' | 'invoiced' | 'paid';
  invoiceDate?: string;
  paidDate?: string;
}

export interface WhiteLabelPortal {
  resellerId: string;
  customDomain: string;
  branding: BrandingConfig;
  customers: ResellerCustomer[];
  projects: any[];
  analytics: PortalAnalytics;
}

export interface PortalAnalytics {
  totalCustomers: number;
  activeProjects: number;
  totalRevenue: number;
  monthlyRecurringRevenue: number;
  customerRetentionRate: number;
  avgProjectValue: number;
}

class WhiteLabelPortalEngine {
  /**
   * Create a new reseller account
   */
  async createResellerAccount(
    companyName: string,
    contactEmail: string,
    billingType: string,
    revenueSplitPercent?: number,
    brandingConfig?: BrandingConfig,
    db?: any
  ): Promise<ResellerAccount> {
    const { data, error } = await db
      .from('reseller_accounts')
      .insert([
        {
          company_name: companyName,
          contact_email: contactEmail,
          billing_type: billingType,
          revenue_split_percent: revenueSplitPercent,
          branding_config: brandingConfig || this.getDefaultBranding(companyName),
          status: 'trial',
          trial_ends_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30-day trial
          created_at: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      companyName: data.company_name,
      contactEmail: data.contact_email,
      customDomain: data.custom_domain,
      brandingConfig: data.branding_config,
      billingType: data.billing_type,
      revenueSplitPercent: data.revenue_split_percent,
      status: data.status,
      createdAt: data.created_at,
      trialEndsAt: data.trial_ends_at,
    };
  }

  /**
   * Set custom domain for reseller
   */
  async setCustomDomain(resellerId: string, customDomain: string, db: any): Promise<void> {
    // Validate domain is available
    const { data: existing } = await db
      .from('reseller_accounts')
      .select('id')
      .eq('custom_domain', customDomain)
      .neq('id', resellerId);

    if (existing && existing.length > 0) {
      throw new Error('Domain already in use');
    }

    // Update reseller account
    const { error } = await db
      .from('reseller_accounts')
      .update({ custom_domain: customDomain })
      .eq('id', resellerId);

    if (error) throw error;
  }

  /**
   * Update reseller branding
   */
  async updateBranding(resellerId: string, branding: BrandingConfig, db: any): Promise<BrandingConfig> {
    const { data, error } = await db
      .from('reseller_accounts')
      .update({ branding_config: branding })
      .eq('id', resellerId)
      .select('branding_config')
      .single();

    if (error) throw error;

    return data.branding_config;
  }

  /**
   * Onboard a customer for a reseller
   */
  async onboardResellerCustomer(
    resellerId: string,
    projectId: string,
    customerName: string,
    email: string,
    phone?: string,
    db?: any
  ): Promise<ResellerCustomer> {
    const { data, error } = await db
      .from('reseller_customers')
      .insert([
        {
          reseller_id: resellerId,
          project_id: projectId,
          customer_name: customerName,
          email,
          phone,
          onboarded_at: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (error) throw error;

    // Send welcome email with custom reseller branding
    await this.sendResellerWelomeEmail(resellerId, email, customerName, db);

    return {
      id: data.id,
      resellerId: data.reseller_id,
      projectId: data.project_id,
      customerName: data.customer_name,
      email: data.email,
      phone: data.phone,
      onboardedAt: data.onboarded_at,
    };
  }

  /**
   * Send welcome email using reseller branding
   */
  private async sendResellerWelomeEmail(
    resellerId: string,
    email: string,
    customerName: string,
    db: any
  ): Promise<void> {
    // Get reseller branding
    const { data: reseller } = await db
      .from('reseller_accounts')
      .select('branding_config, custom_domain')
      .eq('id', resellerId)
      .single();

    if (!reseller) return;

    const branding = reseller.branding_config;
    const portalUrl = reseller.custom_domain || `https://portal.saguarocrm.com?reseller=${resellerId}`;

    // Email would be sent via email service
    console.log(`Welcome email sent to ${email} using ${branding.company_name} branding`);
  }

  /**
   * Get reseller portal configuration
   */
  async getResellerPortal(resellerId: string, db: any): Promise<WhiteLabelPortal> {
    const { data: reseller, error: resellerError } = await db
      .from('reseller_accounts')
      .select('*')
      .eq('id', resellerId)
      .single();

    if (resellerError || !reseller) {
      throw new Error('Reseller not found');
    }

    const { data: customers } = await db
      .from('reseller_customers')
      .select('*')
      .eq('reseller_id', resellerId);

    const { data: projects } = await db
      .from('projects')
      .select('*')
      .in(
        'id',
        customers?.map((c: any) => c.project_id) || []
      );

    const analytics = await this.getResellerAnalytics(resellerId, db);

    return {
      resellerId,
      customDomain: reseller.custom_domain,
      branding: reseller.branding_config,
      customers: customers || [],
      projects: projects || [],
      analytics,
    };
  }

  /**
   * Generate billing for reseller (monthly)
   */
  async generateResellerBilling(resellerId: string, db: any): Promise<ResellerBilling> {
    const { data: reseller } = await db
      .from('reseller_accounts')
      .select('billing_type, revenue_split_percent')
      .eq('id', resellerId)
      .single();

    if (!reseller) throw new Error('Reseller not found');

    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);

    let chargeAmount = 0;

    if (reseller.billing_type === 'revenue_share') {
      // Calculate revenue share from completed projects
      const { data: bills } = await db
        .rpc('get_reseller_monthly_revenue', {
          reseller_id: resellerId,
          start_date: monthStart.toISOString(),
          end_date: monthEnd.toISOString(),
        });

      chargeAmount = (bills?.total_revenue || 0) * (reseller.revenue_split_percent / 100);
    } else if (reseller.billing_type === 'per_user') {
      // $99/user/month
      const { count: userCount } = await db
        .from('reseller_customers')
        .select('*', { count: 'exact' })
        .eq('reseller_id', resellerId);

      chargeAmount = (userCount || 0) * 99;
    } else if (reseller.billing_type === 'tiered') {
      // Tiered pricing based on usage
      const { count: customerCount } = await db
        .from('reseller_customers')
        .select('*', { count: 'exact' })
        .eq('reseller_id', resellerId);

      if (customerCount! <= 10) chargeAmount = 299;
      else if (customerCount! <= 50) chargeAmount = 799;
      else chargeAmount = 1999;
    }

    const { data: billing, error } = await db
      .from('reseller_billing')
      .insert([
        {
          reseller_id: resellerId,
          billing_period_start: monthStart.toISOString(),
          billing_period_end: monthEnd.toISOString(),
          charge_amount: chargeAmount,
          status: 'draft',
          created_at: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (error) throw error;

    return {
      id: billing.id,
      resellerId: billing.reseller_id,
      billingPeriodStart: billing.billing_period_start,
      billingPeriodEnd: billing.billing_period_end,
      chargeAmount: billing.charge_amount,
      status: billing.status,
    };
  }

  /**
   * Get analytics for reseller portal
   */
  private async getResellerAnalytics(resellerId: string, db: any): Promise<PortalAnalytics> {
    const { count: totalCustomers } = await db
      .from('reseller_customers')
      .select('*', { count: 'exact' })
      .eq('reseller_id', resellerId);

    const { count: activeProjects } = await db
      .from('projects')
      .select('*', { count: 'exact' })
      .eq('reseller_id', resellerId)
      .eq('status', 'active');

    // Calculate total revenue from reseller's projects
    const { data: projects } = await db
      .from('projects')
      .select('budget')
      .eq('reseller_id', resellerId);

    const totalRevenue = projects?.reduce((sum: number, p: any) => sum + (p.budget || 0), 0) || 0;
    const monthlyRecurringRevenue = totalRevenue / 12; // Simplified

    return {
      totalCustomers: totalCustomers || 0,
      activeProjects: activeProjects || 0,
      totalRevenue,
      monthlyRecurringRevenue,
      customerRetentionRate: 95, // Placeholder
      avgProjectValue: totalCustomers! > 0 ? totalRevenue / totalCustomers! : 0,
    };
  }

  /**
   * Default branding configuration
   */
  private getDefaultBranding(companyName: string): BrandingConfig {
    return {
      logoUrl: 'https://via.placeholder.com/200x60?text=Logo',
      primaryColor: '#1F2937',
      secondaryColor: '#3B82F6',
      accentColor: '#10B981',
      fontFamily: 'Inter, sans-serif',
      companyName,
      supportEmail: 'support@' + companyName.toLowerCase().replace(/\s/g, '') + '.com',
    };
  }

  /**
   * Get reseller portal template (white-label)
   */
  async getPortalTemplate(resellerId: string, db: any): Promise<string> {
    const { data: reseller } = await db
      .from('reseller_accounts')
      .select('branding_config')
      .eq('id', resellerId)
      .single();

    if (!reseller) throw new Error('Reseller not found');

    const branding = reseller.branding_config;

    return `
    <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${branding.company_name} - Project Portal</title>
        <style>
          :root {
            --primary: ${branding.primaryColor};
            --secondary: ${branding.secondaryColor};
            --accent: ${branding.accentColor};
          }
          * {
            font-family: ${branding.fontFamily};
            color: var(--primary);
          }
          .header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            padding: 2rem;
            text-align: center;
          }
          .logo {
            max-width: 200px;
            margin-bottom: 1rem;
          }
          .nav {
            background: var(--primary);
            color: white;
            padding: 1rem 2rem;
          }
          .nav a {
            color: white;
            margin-right: 2rem;
            text-decoration: none;
          }
          .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
          }
          body {
            background-color: #f9fafb;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <img src="${branding.logoUrl}" alt="Logo" class="logo">
          <h1>${branding.company_name}</h1>
          <p>Construction Project Management Portal</p>
        </div>
        <div class="nav">
          <a href="/dashboard">Dashboard</a>
          <a href="/projects">Projects</a>
          <a href="/reports">Reports</a>
          <a href="/support">Support</a>
        </div>
        <div class="container">
          <!-- Portal content here -->
        </div>
        <footer style="text-align: center; padding: 2rem; color: #6b7280;">
          <p>${branding.company_name} © 2024 | <a href="mailto:${branding.supportEmail}">${branding.supportEmail}</a></p>
        </footer>
      </body>
    </html>
    `;
  }
}

export const whiteLabelPortal = new WhiteLabelPortalEngine();
