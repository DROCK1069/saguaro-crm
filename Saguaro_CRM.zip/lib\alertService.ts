/**
 * Slack & Microsoft Teams Alert System
 * Real-time notifications with formatted payloads
 */

export type AlertSeverity = 'info' | 'warning' | 'critical';

export interface Alert {
  id: string;
  entity: 'rfi' | 'invoice' | 'task' | 'project';
  entityId: string;
  severity: AlertSeverity;
  title: string;
  description: string;
  actionUrl: string;
  createdAt: number;
}

export interface SlackConfig {
  webhookUrl: string;
  channel: string;
  mentionUsers?: Record<AlertSeverity, string[]>;
}

export interface TeamsConfig {
  webhookUrl: string;
  mentionUsers?: Record<AlertSeverity, string[]>;
}

class AlertService {
  private slackConfigs: Map<string, SlackConfig> = new Map();
  private teamsConfigs: Map<string, TeamsConfig> = new Map();

  async registerSlackWebhook(projectId: string, webhookUrl: string, channel: string) {
    this.slackConfigs.set(projectId, { webhookUrl, channel });
    // Persist to DB
    await fetch('/api/alerts/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, type: 'slack', webhookUrl, channel }),
    });
  }

  async registerTeamsWebhook(projectId: string, webhookUrl: string) {
    this.teamsConfigs.set(projectId, { webhookUrl });
    // Persist to DB
    await fetch('/api/alerts/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, type: 'teams', webhookUrl }),
    });
  }

  async sendAlert(projectId: string, alert: Omit<Alert, 'id' | 'createdAt'>) {
    const fullAlert: Alert = {
      ...alert,
      id: crypto.randomUUID(),
      createdAt: Date.now(),
    };

    // Send to Slack if configured
    const slackCfg = this.slackConfigs.get(projectId);
    if (slackCfg) {
      await this.sendSlackAlert(slackCfg, fullAlert);
    }

    // Send to Teams if configured
    const teamsCfg = this.teamsConfigs.get(projectId);
    if (teamsCfg) {
      await this.sendTeamsAlert(teamsCfg, fullAlert);
    }

    // Log to DB
    await fetch('/api/alerts/log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, ...fullAlert }),
    });
  }

  private async sendSlackAlert(config: SlackConfig, alert: Alert) {
    const colors = {
      info: '#36a64f',
      warning: '#ff9900',
      critical: '#ff0000',
    };

    const messagePayload: Record<string, any> = {
      channel: config.channel,
      attachments: [
        {
          color: colors[alert.severity],
          title: alert.title,
          text: alert.description,
          fields: [
            {
              title: 'Entity',
              value: `${alert.entity.toUpperCase()} #${alert.entityId}`,
              short: true,
            },
            {
              title: 'Severity',
              value: alert.severity.toUpperCase(),
              short: true,
            },
          ],
          actions: [
            {
              type: 'button',
              text: 'View in Saguaro',
              url: alert.actionUrl,
            },
          ],
          ts: Math.floor(alert.createdAt / 1000),
        },
      ],
    };

    try {
      const res = await fetch(config.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(messagePayload),
      });
      if (!res.ok) {
        console.error(`Slack alert failed: ${res.status}`);
      }
    } catch (err) {
      console.error('Slack alert error:', err);
    }
  }

  private async sendTeamsAlert(config: TeamsConfig, alert: Alert) {
    const colors = {
      info: '0078d4',
      warning: 'ff9500',
      critical: 'cc0000',
    };

    const messagePayload = {
      '@type': 'MessageCard',
      '@context': 'https://schema.org/extensions',
      summary: alert.title,
      themeColor: colors[alert.severity],
      sections: [
        {
          activityTitle: alert.title,
          activitySubtitle: `${alert.entity.toUpperCase()} #${alert.entityId}`,
          text: alert.description,
          facts: [
            {
              name: 'Severity',
              value: `<strong>${alert.severity.toUpperCase()}</strong>`,
            },
            {
              name: 'Time',
              value: new Date(alert.createdAt).toLocaleString(),
            },
          ],
        },
      ],
      potentialAction: [
        {
          '@type': 'OpenUri',
          name: 'View in Saguaro',
          targets: [{ os: 'default', uri: alert.actionUrl }],
        },
      ],
    };

    try {
      const res = await fetch(config.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(messagePayload),
      });
      if (!res.ok) {
        console.error(`Teams alert failed: ${res.status}`);
      }
    } catch (err) {
      console.error('Teams alert error:', err);
    }
  }

  // Trigger alerts based on business logic
  async checkAndAlert(db: any, projectId: string) {
    // Check for overdue RFIs
    const { data: overdueRFIs } = await db
      .from('rfis')
      .select('*')
      .eq('project_id', projectId)
      .eq('status', 'open')
      .lt('due_date', new Date().toISOString())
      .order('due_date', { ascending: true });

    for (const rfi of overdueRFIs || []) {
      const daysOverdue = Math.floor(
        (Date.now() - new Date(rfi.due_date).getTime()) / (1000 * 60 * 60 * 24)
      );
      await this.sendAlert(projectId, {
        entity: 'rfi',
        entityId: rfi.id,
        severity: daysOverdue > 7 ? 'critical' : 'warning',
        title: `RFI #${rfi.number} Overdue`,
        description: `RFI is ${daysOverdue} days overdue. Last response from ${rfi.assigned_to || 'unknown'}.`,
        actionUrl: `/project/${projectId}/rfis/${rfi.id}`,
      });
    }

    // Check for unpaid invoices
    const { data: unpaidInvoices } = await db
      .from('invoices')
      .select('*')
      .eq('project_id', projectId)
      .eq('status', 'pending')
      .lt('due_date', new Date().toISOString());

    for (const invoice of unpaidInvoices || []) {
      const daysPast = Math.floor(
        (Date.now() - new Date(invoice.due_date).getTime()) / (1000 * 60 * 60 * 24)
      );
      await this.sendAlert(projectId, {
        entity: 'invoice',
        entityId: invoice.id,
        severity: daysPast > 30 ? 'critical' : daysPast > 14 ? 'warning' : 'info',
        title: `Invoice #${invoice.number} Payment Due`,
        description: `$${invoice.amount.toFixed(2)} is ${daysPast} days past due.`,
        actionUrl: `/project/${projectId}/invoices/${invoice.id}`,
      });
    }

    // Check for schedule slippage
    const { data: delayedTasks } = await db
      .from('schedule_tasks')
      .select('*')
      .eq('project_id', projectId)
      .eq('status', 'in_progress')
      .lt('planned_finish', new Date().toISOString())
      .is('actual_finish', null);

    for (const task of delayedTasks || []) {
      const daysLate = Math.floor(
        (Date.now() - new Date(task.planned_finish).getTime()) / (1000 * 60 * 60 * 24)
      );
      await this.sendAlert(projectId, {
        entity: 'task',
        entityId: task.id,
        severity: daysLate > 7 ? 'critical' : 'warning',
        title: `Task Behind Schedule: ${task.name}`,
        description: `Task is ${daysLate} days late. Assigned to ${task.assigned_to || 'unassigned'}.`,
        actionUrl: `/project/${projectId}/schedule/${task.id}`,
      });
    }
  }
}

export const alertService = new AlertService();

// Export convenience functions
export async function sendSlackAlert(projectId: string, alert: Omit<Alert, 'id' | 'createdAt'>) {
  return alertService.sendAlert(projectId, alert);
}

export async function sendTeamsAlert(projectId: string, alert: Omit<Alert, 'id' | 'createdAt'>) {
  return alertService.sendAlert(projectId, alert);
}
