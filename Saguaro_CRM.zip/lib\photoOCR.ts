/**
 * Photo OCR Service
 * Extracts text from construction photos using cloud vision or local processing
 * Detects: measurements, labels, damage descriptions, compliance issues
 */

export interface OCRResult {
  photoId: string;
  extractedText: string;
  textBlocks: Array<{
    text: string;
    confidence: number;
    boundingBox: { x: number; y: number; width: number; height: number };
  }>;
  detectedObjects: Array<{
    label: string;
    confidence: number;
    bounds: { x: number; y: number; width: number; height: number };
  }>;
  measurements: Array<{
    value: string;
    unit: string;
    context: string;
  }>;
  issues: Array<{
    type: string;
    description: string;
    severity: 'low' | 'medium' | 'high';
  }>;
  processingTime: number;
}

class PhotoOCRService {
  private apiKey: string;
  private apiEndpoint: string;

  constructor(apiKey?: string, endpoint?: string) {
    this.apiKey = apiKey || process.env.VISION_API_KEY || '';
    this.apiEndpoint = endpoint || process.env.VISION_API_ENDPOINT || 'https://vision.googleapis.com/v1/images:annotate';
  }

  /**
   * Extract text from photo using Google Cloud Vision or similar
   */
  async extractText(imageUrl: string): Promise<string> {
    if (!this.apiKey) {
      // Fallback to placeholder for demo
      return 'OCR placeholder text - configure VISION_API_KEY for real processing';
    }

    try {
      const response = await fetch(this.apiEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requests: [
            {
              image: { source: { imageUri: imageUrl } },
              features: [
                { type: 'TEXT_DETECTION', maxResults: 10 },
                { type: 'OBJECT_LOCALIZATION', maxResults: 20 },
                { type: 'LABEL_DETECTION', maxResults: 10 },
              ],
            },
          ],
          key: this.apiKey,
        }),
      });

      if (!response.ok) {
        throw new Error(`Vision API error: ${response.statusText}`);
      }

      const data = await response.json();
      return this.parseVisionResponse(data);
    } catch (err) {
      console.error('OCR extraction failed:', err);
      return '';
    }
  }

  /**
   * Detect measurements from extracted text
   * Looks for patterns like "12 ft", "8.5 m", "2'3\"", etc.
   */
  detectMeasurements(text: string): Array<{ value: string; unit: string; context: string }> {
    const measurements: Array<{ value: string; unit: string; context: string }> = [];

    // Pattern: number + unit (ft, m, cm, in, mm, etc.)
    const patterns = [
      /(\d+(?:\.\d+)?)\s*(ft|feet|foot|m|meter|meters|cm|centimeter|in|inch|inches|mm|millimeter)/gi,
      /(\d+)'(\d+)?\"?/g, // 12'3" format
      /(\d+)\s*x\s*(\d+)\s*(ft|m|cm)?/gi, // 12 x 8 format
    ];

    const words = text.split(/\s+/);

    patterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        measurements.push({
          value: match[1],
          unit: match[2] || 'unknown',
          context: this.getContext(text, match.index),
        });
      }
    });

    return measurements;
  }

  /**
   * Detect potential issues or concerns in photo
   * Keywords: crack, damage, leak, mold, missing, misaligned, etc.
   */
  detectIssues(text: string): Array<{ type: string; description: string; severity: 'low' | 'medium' | 'high' }> {
    const issues: Array<{ type: string; description: string; severity: 'low' | 'medium' | 'high' }> = [];

    const criticalKeywords = [
      { word: 'crack', type: 'structural', severity: 'high' as const },
      { word: 'collapse', type: 'structural', severity: 'high' as const },
      { word: 'leak', type: 'water', severity: 'high' as const },
      { word: 'flood', type: 'water', severity: 'high' as const },
      { word: 'mold', type: 'health', severity: 'high' as const },
      { word: 'asbestos', type: 'health', severity: 'high' as const },
      { word: 'damage', type: 'general', severity: 'medium' as const },
      { word: 'missing', type: 'component', severity: 'medium' as const },
      { word: 'broken', type: 'component', severity: 'medium' as const },
      { word: 'misaligned', type: 'alignment', severity: 'low' as const },
      { word: 'rust', type: 'corrosion', severity: 'low' as const },
    ];

    const lowerText = text.toLowerCase();

    criticalKeywords.forEach(({ word, type, severity }) => {
      if (lowerText.includes(word)) {
        issues.push({
          type,
          description: `Detected: ${word}`,
          severity,
        });
      }
    });

    return issues;
  }

  /**
   * Get context around a match (surrounding words)
   */
  private getContext(text: string, index: number, contextLength: number = 50): string {
    const start = Math.max(0, index - contextLength);
    const end = Math.min(text.length, index + contextLength);
    return text.substring(start, end).trim();
  }

  /**
   * Parse Google Cloud Vision API response
   */
  private parseVisionResponse(data: any): string {
    if (!data.responses || data.responses.length === 0) {
      return '';
    }

    const response = data.responses[0];
    if (!response.textAnnotations) {
      return '';
    }

    // First annotation is the full text
    return response.textAnnotations[0].description || '';
  }

  /**
   * Full OCR processing pipeline
   */
  async processPhoto(imageUrl: string, photoId: string, db: any): Promise<OCRResult> {
    const startTime = Date.now();

    // 1. Extract text
    const extractedText = await this.extractText(imageUrl);

    // 2. Detect measurements
    const measurements = this.detectMeasurements(extractedText);

    // 3. Detect issues
    const issues = this.detectIssues(extractedText);

    // 4. Parse text blocks (simplified)
    const textBlocks = this.parseTextBlocks(extractedText);

    // 5. Detect objects (simplified)
    const detectedObjects = this.detectObjects(textBlocks);

    // 6. Store results in database
    const result: OCRResult = {
      photoId,
      extractedText,
      textBlocks,
      detectedObjects,
      measurements,
      issues,
      processingTime: Date.now() - startTime,
    };

    // Save to database
    await db.from('photo_ocr').insert({
      photo_id: photoId,
      extracted_text: extractedText,
      measurements: measurements,
      detected_issues: issues,
      processing_time: result.processingTime,
      created_at: new Date().toISOString(),
    });

    return result;
  }

  /**
   * Parse text into blocks (simplified)
   */
  private parseTextBlocks(text: string): Array<{
    text: string;
    confidence: number;
    boundingBox: { x: number; y: number; width: number; height: number };
  }> {
    // Split on newlines or multiple spaces
    const blocks = text.split(/\n+/).filter(line => line.trim().length > 0);

    return blocks.map((block, index) => ({
      text: block.trim(),
      confidence: 0.95,
      boundingBox: {
        x: 0,
        y: index * 50,
        width: 1000,
        height: 50,
      },
    }));
  }

  /**
   * Detect objects in text (simplified - looks for construction keywords)
   */
  private detectObjects(textBlocks: any[]): Array<{
    label: string;
    confidence: number;
    bounds: { x: number; y: number; width: number; height: number };
  }> {
    const constructionKeywords = [
      'wall', 'door', 'window', 'floor', 'ceiling', 'roof', 'beam', 'column',
      'foundation', 'concrete', 'brick', 'steel', 'pipe', 'wire', 'cable',
      'scaffold', 'formwork', 'rebar', 'joint', 'seam', 'weld'
    ];

    const detected: Array<{
      label: string;
      confidence: number;
      bounds: { x: number; y: number; width: number; height: number };
    }> = [];

    textBlocks.forEach((block: any, index: number) => {
      const lower = block.text.toLowerCase();
      constructionKeywords.forEach(keyword => {
        if (lower.includes(keyword)) {
          detected.push({
            label: keyword,
            confidence: 0.85,
            bounds: {
              x: 0,
              y: index * 50,
              width: 1000,
              height: 50,
            },
          });
        }
      });
    });

    return detected;
  }

  /**
   * Generate AI-driven insights from OCR results
   */
  async generateInsights(ocrResult: OCRResult): Promise<string> {
    let insights = '';

    // Issues insight
    if (ocrResult.issues.length > 0) {
      const criticalIssues = ocrResult.issues.filter(i => i.severity === 'high');
      if (criticalIssues.length > 0) {
        insights += `⚠️ CRITICAL ISSUES DETECTED:\n${criticalIssues.map(i => `- ${i.description}`).join('\n')}\n\n`;
      }
    }

    // Measurements insight
    if (ocrResult.measurements.length > 0) {
      insights += `📏 MEASUREMENTS FOUND:\n${ocrResult.measurements.slice(0, 5).map(m => `- ${m.value} ${m.unit}`).join('\n')}\n\n`;
    }

    // Objects insight
    if (ocrResult.detectedObjects.length > 0) {
      const uniqueObjects = [...new Set(ocrResult.detectedObjects.map(o => o.label))];
      insights += `🔍 COMPONENTS DETECTED:\n${uniqueObjects.slice(0, 5).join(', ')}\n`;
    }

    return insights;
  }
}

export const photoOCR = new PhotoOCRService();
