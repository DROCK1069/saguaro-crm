/**
 * Predictive Budget Analytics Engine
 * Forecasts project budgets using statistical analysis
 */

export interface BudgetForecast {
  projectId: string;
  contractValue: number;
  currentSpent: number;
  projectedFinal: number;
  variance: number;
  variancePercent: number;
  remainingDays: number;
  burnRate: number;
  riskScore: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  confidenceInterval: { low: number; high: number };
  generatedAt: number;
}

class PredictiveAnalytics {
  /**
   * Linear regression forecast based on historical burn rate
   */
  async forecastBudget(
    projectId: string,
    contractValue: number,
    actualCosts: Array<{ date: string; amount: number }>,
    plannedEnd: string
  ): Promise<BudgetForecast> {
    // Sort by date
    actualCosts.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    if (actualCosts.length < 2) {
      return this.createNeutralForecast(projectId, contractValue);
    }

    // Calculate days elapsed and total spent
    const startDate = new Date(actualCosts[0].date);
    const endDate = new Date(plannedEnd);
    const today = new Date();
    const totalDays = Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const elapsedDays = Math.floor((today.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const remainingDays = Math.max(0, totalDays - elapsedDays);

    // Calculate cumulative amount and prepare for linear regression
    let cumulativeAmount = 0;
    const dataPoints: Array<{ x: number; y: number }> = [];

    for (let i = 0; i < actualCosts.length; i++) {
      cumulativeAmount += actualCosts[i].amount;
      const daysFromStart = Math.floor(
        (new Date(actualCosts[i].date).getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)
      );
      dataPoints.push({ x: daysFromStart, y: cumulativeAmount });
    }

    // Linear regression: y = mx + b
    const { slope: burnRate, intercept } = this.linearRegression(dataPoints);

    // Project to end date
    const projectedFinal = burnRate * totalDays + intercept;
    const currentSpent = dataPoints[dataPoints.length - 1].y;

    // Calculate variance
    const variance = projectedFinal - contractValue;
    const variancePercent = (variance / contractValue) * 100;

    // Risk score (0-100): Based on variance and confidence
    const riskScore = Math.min(100, Math.abs(variancePercent) * 1.5);
    const riskLevel =
      riskScore >= 75
        ? 'critical'
        : riskScore >= 50
          ? 'high'
          : riskScore >= 25
            ? 'medium'
            : 'low';

    // Confidence interval (±10% of projection)
    const margin = projectedFinal * 0.1;

    return {
      projectId,
      contractValue,
      currentSpent,
      projectedFinal: Math.round(projectedFinal),
      variance: Math.round(variance),
      variancePercent: Math.round(variancePercent * 10) / 10,
      remainingDays: Math.max(0, remainingDays),
      burnRate: Math.round(burnRate * 100) / 100,
      riskScore: Math.round(riskScore),
      riskLevel,
      confidenceInterval: {
        low: Math.round(projectedFinal - margin),
        high: Math.round(projectedFinal + margin),
      },
      generatedAt: Date.now(),
    };
  }

  /**
   * Linear regression calculation
   * @returns slope (m) and intercept (b)
   */
  private linearRegression(points: Array<{ x: number; y: number }>): { slope: number; intercept: number } {
    const n = points.length;
    let sumX = 0,
      sumY = 0,
      sumXY = 0,
      sumX2 = 0;

    for (const p of points) {
      sumX += p.x;
      sumY += p.y;
      sumXY += p.x * p.y;
      sumX2 += p.x * p.x;
    }

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;

    return { slope, intercept };
  }

  private createNeutralForecast(projectId: string, contractValue: number): BudgetForecast {
    return {
      projectId,
      contractValue,
      currentSpent: 0,
      projectedFinal: contractValue,
      variance: 0,
      variancePercent: 0,
      remainingDays: 0,
      burnRate: 0,
      riskScore: 0,
      riskLevel: 'low',
      confidenceInterval: { low: contractValue * 0.9, high: contractValue * 1.1 },
      generatedAt: Date.now(),
    };
  }

  /**
   * Generate forecast alerts based on risk
   */
  async generateAlerts(forecast: BudgetForecast): Promise<string[]> {
    const alerts: string[] = [];

    if (forecast.riskLevel === 'critical') {
      alerts.push(
        `CRITICAL: Project forecast to exceed budget by $${Math.abs(forecast.variance).toLocaleString()}`
      );
    } else if (forecast.riskLevel === 'high') {
      alerts.push(
        `WARNING: Project forecast to overflow by ${forecast.variancePercent.toFixed(1)}% ($${Math.abs(forecast.variance).toLocaleString()})`
      );
    }

    if (forecast.remainingDays > 0 && forecast.projectedFinal > forecast.contractValue) {
      const dailyAdjustment = forecast.variance / forecast.remainingDays;
      alerts.push(
        `Need to reduce daily burn by $${Math.abs(dailyAdjustment).toFixed(2)} to stay within budget`
      );
    }

    return alerts;
  }

  /**
   * Compare multiple projects and identify at-risk ones
   */
  async rankProjectsByRisk(
    projects: Array<{ id: string; contractValue: number; plannedEnd: string }>,
    db: any
  ): Promise<Array<BudgetForecast>> {
    const forecasts: BudgetForecast[] = [];

    for (const project of projects) {
      // Get actual costs from database
      const { data: costs } = await db
        .from('cost_entries')
        .select('date,amount')
        .eq('project_id', project.id)
        .order('date', { ascending: true });

      const forecast = await this.forecastBudget(
        project.id,
        project.contractValue,
        costs || [],
        project.plannedEnd
      );
      forecasts.push(forecast);
    }

    // Sort by risk score descending
    forecasts.sort((a, b) => b.riskScore - a.riskScore);
    return forecasts;
  }
}

export const predictiveAnalytics = new PredictiveAnalytics();

// Export convenience functions
export const forecastBudget = (
  projectId: string,
  contractValue: number,
  actualCosts: Array<{ date: string; amount: number }>,
  plannedEnd: string
) => predictiveAnalytics.forecastBudget(projectId, contractValue, actualCosts, plannedEnd);

export const rankProjectsByRisk = (projects: any[], costData: any[]) =>
  predictiveAnalytics.rankProjectsByRisk(projects, costData);
