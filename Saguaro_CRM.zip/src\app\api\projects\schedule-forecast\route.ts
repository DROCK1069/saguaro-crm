import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/supabase/admin';
import { scheduleVariance } from '@/lib/scheduleVariance';

/**
 * Schedule Variance Forecasting API
 * Predicts project completion dates and identifies schedule risks
 * 
 * POST /api/projects/{projectId}/schedule-forecast
 * GET /api/projects/{projectId}/schedule-forecast
 */

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const { projectId } = await request.json();

    if (!projectId) {
      return NextResponse.json(
        { error: 'Project ID required' },
        { status: 400 }
      );
    }

    const db = supabaseAdmin;

    // Get all tasks for the project
    const { data: tasks, error: tasksError } = await db
      .from('tasks')
      .select('id, name, planned_start, planned_finish, actual_start, actual_finish, percent_complete, dependencies')
      .eq('project_id', projectId);

    if (tasksError || !tasks) {
      return NextResponse.json(
        { error: 'Failed to load project tasks' },
        { status: 400 }
      );
    }

    // Generate forecast
    const transformedTasks = tasks.map((task: any) => ({
      taskId: task.id,
      taskName: task.name,
      plannedStart: task.planned_start,
      plannedFinish: task.planned_finish,
      actualStart: task.actual_start,
      actualFinish: task.actual_finish,
      percentComplete: task.percent_complete,
      dependencies: task.dependencies || [],
      resourcesAllocated: task.resources_allocated || 1,
    }));
    const forecast = await scheduleVariance.forecastSchedule(projectId, transformedTasks, db);

    return NextResponse.json(
      {
        success: true,
        data: forecast,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Schedule forecast error:', error);
    return NextResponse.json(
      { error: 'Forecast generation failed' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');

    if (!projectId) {
      return NextResponse.json(
        { error: 'Project ID required' },
        { status: 400 }
      );
    }

    const db = supabaseAdmin;

    // Get latest forecast
    const { data, error } = await db
      .from('schedule_forecasts')
      .select('*')
      .eq('project_id', projectId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (error || !data) {
      return NextResponse.json(
        { error: 'No forecast found' },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        success: true,
        data,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error retrieving forecast:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve forecast' },
      { status: 500 }
    );
  }
}
