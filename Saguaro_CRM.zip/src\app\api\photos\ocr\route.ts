import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/supabase/admin';
import { photoOCR } from '@/lib/photoOCR';

/**
 * Photo OCR Processing Endpoint
 * Extracts text and detects issues from construction photos
 * 
 * POST /api/photos/ocr
 * Body: { photoId: string, imageUrl: string, projectId: string }
 * Response: OCRResult with extracted text, measurements, issues, objects
 */

interface OCRRequest {
  photoId: string;
  imageUrl: string;
  projectId: string;
}

interface OCRResponse {
  success: boolean;
  data?: {
    photoId: string;
    extractedText: string;
    measurements: Array<{
      value: number;
      unit: string;
      context: string;
    }>;
    detectedIssues: Array<{
      type: string;
      description: string;
      severity: 'critical' | 'medium' | 'low';
    }>;
    detectedObjects: Array<{
      label: string;
      confidence: number;
      boundingBox?: { x: number; y: number; width: number; height: number };
    }>;
    insights: string;
    processingTime: number;
  };
  error?: string;
}

export async function POST(request: NextRequest): Promise<NextResponse<OCRResponse>> {
  try {
    const body: OCRRequest = await request.json();
    const { photoId, imageUrl, projectId } = body;

    // Validate input
    if (!photoId || !imageUrl || !projectId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Missing required fields: photoId, imageUrl, projectId',
        },
        { status: 400 }
      );
    }

    const db = supabaseAdmin;
    const startTime = Date.now();

    // Process photo
    const result = await photoOCR.processPhoto(imageUrl, photoId, db);
    const processingTime = Date.now() - startTime;

    // Return successful response
    return NextResponse.json(
      {
        success: true,
        data: {
          photoId,
          extractedText: result.extractedText,
          measurements: result.measurements.map((m: any) => ({
            value: typeof m.value === 'string' ? parseFloat(m.value) : m.value,
            unit: m.unit,
            context: m.context,
          })),
          detectedIssues: result.issues?.map((i: any) => ({
            type: i.type,
            description: i.description,
            severity: i.severity === 'high' ? 'critical' : i.severity,
          })) || [],
          detectedObjects: result.detectedObjects,
          insights: result.textBlocks?.map((t: any) => t.text).join(' ') || '',
          processingTime,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('OCR processing error:', error);

    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return NextResponse.json(
      {
        success: false,
        error: `OCR processing failed: ${errorMessage}`,
      },
      { status: 500 }
    );
  }
}

/**
 * GET - Retrieve OCR results for a photo
 * GET /api/photos/ocr?photoId=<id>
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const { searchParams } = new URL(request.url);
    const photoId = searchParams.get('photoId');

    if (!photoId) {
      return NextResponse.json(
        { error: 'Missing photoId parameter' },
        { status: 400 }
      );
    }

    const db = supabaseAdmin;

    // Fetch OCR results from database
    const { data, error } = await db
      .from('photo_ocr')
      .select('*')
      .eq('photo_id', photoId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (error || !data) {
      return NextResponse.json(
        { error: 'OCR results not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        success: true,
        data: {
          photoId: data.photo_id,
          extractedText: data.extracted_text,
          measurements: data.measurements,
          detectedIssues: data.detected_issues,
          detectedObjects: data.detected_objects,
          insights: data.insights,
          createdAt: data.created_at,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error retrieving OCR results:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve OCR results' },
      { status: 500 }
    );
  }
}

/**
 * BATCH endpoint - Process multiple photos
 * POST /api/photos/ocr/batch
 * Body: { photos: Array<{ photoId, imageUrl, projectId }> }
 */
export async function PUT(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { photos } = body;

    if (!Array.isArray(photos) || photos.length === 0) {
      return NextResponse.json(
        { error: 'Invalid batch request' },
        { status: 400 }
      );
    }

    const db = supabaseAdmin;
    const results = [];

    for (const photo of photos) {
      try {
        const result = await photoOCR.processPhoto(photo.imageUrl, photo.photoId, db);
        results.push({
          photoId: photo.photoId,
          success: true,
          data: result,
        });
      } catch (err) {
        results.push({
          photoId: photo.photoId,
          success: false,
          error: err instanceof Error ? err.message : 'Unknown error',
        });
      }
    }

    return NextResponse.json(
      {
        success: true,
        processed: results.length,
        results,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Batch OCR processing error:', error);
    return NextResponse.json(
      { error: 'Batch processing failed' },
      { status: 500 }
    );
  }
}
